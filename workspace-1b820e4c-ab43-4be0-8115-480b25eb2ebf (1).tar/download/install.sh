#!/bin/bash

#######################################################################
# SINCETUR VIAGENS E TURISMO - Script de Instalação
# Portal de Agência de Viagens ERP
# Versão: 1.0.0
#######################################################################

set -e

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Log com cores
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Banner
show_banner() {
    clear
    echo ""
    echo -e "${BLUE}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                                                              ║${NC}"
    echo -e "${BLUE}║     ███████╗██╗███╗   ██╗████████╗ █████╗ ██╗                ║${NC}"
    echo -e "${BLUE}║     ██╔════╝██║████╗  ██║╚══██╔══╝██╔══██╗██║                ║${NC}"
    echo -e "${BLUE}║     ███████╗██║██╔██╗ ██║   ██║   ███████║██║                ║${NC}"
    echo -e "${BLUE}║     ╚════██║██║██║╚██╗██║   ██║   ██╔══██║██║                ║${NC}"
    echo -e "${BLUE}║     ███████║██║██║ ╚████║   ██║   ██║  ██║███████╗           ║${NC}"
    echo -e "${BLUE}║     ╚══════╝╚═╝╚═╝  ╚═══╝   ╚═╝   ╚═╝  ╚═╝╚══════╝           ║${NC}"
    echo -e "${BLUE}║                                                              ║${NC}"
    echo -e "${BLUE}║              VIAGENS E TURISMO                               ║${NC}"
    echo -e "${BLUE}║                                                              ║${NC}"
    echo -e "${BLUE}║     Portal ERP - Script de Instalação                        ║${NC}"
    echo -e "${BLUE}║     Versão 1.0.0                                             ║${NC}"
    echo -e "${BLUE}║                                                              ║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

# Verificar se está a correr como root
check_root() {
    if [ "$EUID" -ne 0 ]; then
        log_error "Este script precisa de ser executado como root (sudo)."
        exit 1
    fi
}

# Detectar sistema operativo
detect_os() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS=$ID
        VER=$VERSION_ID
    elif [ -f /etc/redhat-release ]; then
        OS=rhel
    else
        OS=$(uname -s)
    fi
    log_info "Sistema operativo detectado: $OS $VER"
}

# Instalar dependências do sistema
install_system_dependencies() {
    log_info "A instalar dependências do sistema..."
    
    if [ "$OS" = "ubuntu" ] || [ "$OS" = "debian" ]; then
        apt-get update
        apt-get install -y \
            curl \
            wget \
            git \
            build-essential \
            python3 \
            nginx \
            certbot \
            python3-certbot-nginx \
            ufw \
            fail2ban \
            unzip \
            sqlite3
    elif [ "$OS" = "centos" ] || [ "$OS" = "rhel" ]; then
        yum update -y
        yum install -y \
            curl \
            wget \
            git \
            gcc \
            make \
            python3 \
            nginx \
            certbot \
            python3-certbot-nginx \
            firewalld \
            fail2ban \
            unzip \
            sqlite
    fi
    
    log_success "Dependências do sistema instaladas."
}

# Instalar Node.js e Bun
install_nodejs() {
    log_info "A instalar Node.js..."
    
    if ! command -v node &> /dev/null; then
        curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
        apt-get install -y nodejs || yum install -y nodejs
        log_success "Node.js instalado: $(node --version)"
    else
        log_info "Node.js já instalado: $(node --version)"
    fi
}

install_bun() {
    log_info "A instalar Bun..."
    
    if ! command -v bun &> /dev/null; then
        curl -fsSL https://bun.sh/install | bash
        export BUN_INSTALL="$HOME/.bun"
        export PATH="$BUN_INSTALL/bin:$PATH"
        log_success "Bun instalado: $(bun --version)"
    else
        log_info "Bun já instalado: $(bun --version)"
    fi
}

# Criar utilizador da aplicação
create_app_user() {
    log_info "A criar utilizador da aplicação..."
    
    if ! id "sincetur" &>/dev/null; then
        useradd -r -s /bin/false sincetur
        log_success "Utilizador 'sincetur' criado."
    else
        log_info "Utilizador 'sincetur' já existe."
    fi
}

# Configurar diretórios
setup_directories() {
    log_info "A configurar directórios..."
    
    APP_DIR="/var/www/sincetur"
    
    mkdir -p $APP_DIR
    mkdir -p $APP_DIR/logs
    mkdir -p $APP_DIR/backups
    
    log_success "Directórios configurados em $APP_DIR"
}

# Clone ou copiar aplicação
setup_application() {
    log_info "A configurar aplicação..."
    
    APP_DIR="/var/www/sincetur"
    
    # Se o código já foi copiado ou clonado
    if [ -d "./src" ]; then
        cp -r . $APP_DIR/
    elif [ -d "../src" ]; then
        cp -r ../. $APP_DIR/
    else
        log_error "Código fonte não encontrado!"
        exit 1
    fi
    
    cd $APP_DIR
    
    # Instalar dependências
    log_info "A instalar dependências npm/bun..."
    bun install
    
    # Configurar ambiente
    if [ ! -f ".env" ]; then
        log_info "A criar ficheiro .env..."
        cat > .env << EOF
# Ambiente
NODE_ENV=production
PORT=3000

# Base de dados
DATABASE_URL="file:$APP_DIR/db/sincetur.db"

# Segurança
NEXTAUTH_SECRET=$(openssl rand -base64 32)
NEXTAUTH_URL=https://sincetur.com

# Email (configurar conforme necessário)
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USER=
SMTP_PASS=
EOF
        log_success "Ficheiro .env criado. Configure as variáveis de ambiente!"
    fi
    
    # Gerar cliente Prisma
    bun run db:generate
    
    # Inicializar base de dados
    bun run db:push
    
    # Executar seed
    bun run db:seed
    
    # Build da aplicação (opcional - para produção)
    # bun run build
    
    log_success "Aplicação configurada."
}

# Configurar permissões
set_permissions() {
    log_info "A configurar permissões..."
    
    APP_DIR="/var/www/sincetur"
    
    chown -R sincetur:sincetur $APP_DIR
    chmod -R 755 $APP_DIR
    chmod 600 $APP_DIR/.env
    
    log_success "Permissões configuradas."
}

# Configurar systemd service
setup_systemd() {
    log_info "A configurar serviço systemd..."
    
    cat > /etc/systemd/system/sincetur.service << EOF
[Unit]
Description=Sincetur Viagens - Portal ERP
Documentation=https://sincetur.com
After=network.target

[Service]
Type=simple
User=sincetur
Group=sincetur
WorkingDirectory=/var/www/sincetur
ExecStart=/root/.bun/bin/bun run start
Restart=on-failure
RestartSec=10
StandardOutput=append:/var/www/sincetur/logs/stdout.log
StandardError=append:/var/www/sincetur/logs/stderr.log
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable sincetur
    
    log_success "Serviço systemd configurado."
}

# Configurar Nginx
setup_nginx() {
    log_info "A configurar Nginx..."
    
    DOMAIN=${1:-"sincetur.com"}
    
    cat > /etc/nginx/sites-available/sincetur << EOF
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;
    
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
    
    location /api {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # Uploads e ficheiros estáticos
    location /uploads {
        alias /var/www/sincetur/public/uploads;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }
    
    client_max_body_size 50M;
}
EOF

    ln -sf /etc/nginx/sites-available/sincetur /etc/nginx/sites-enabled/
    rm -f /etc/nginx/sites-enabled/default
    
    nginx -t
    systemctl restart nginx
    
    log_success "Nginx configurado para $DOMAIN"
}

# Configurar SSL com Let's Encrypt
setup_ssl() {
    DOMAIN=${1:-"sincetur.com"}
    
    log_info "A configurar SSL..."
    
    certbot --nginx -d $DOMAIN -d www.$DOMAIN --non-interactive --agree-tos --email admin@$DOMAIN
    
    log_success "SSL configurado para $DOMAIN"
}

# Configurar firewall
setup_firewall() {
    log_info "A configurar firewall..."
    
    if command -v ufw &> /dev/null; then
        ufw default deny incoming
        ufw default allow outgoing
        ufw allow ssh
        ufw allow 'Nginx Full'
        ufw --force enable
        log_success "UFW configurado."
    elif command -v firewall-cmd &> /dev/null; then
        systemctl start firewalld
        systemctl enable firewalld
        firewall-cmd --permanent --add-service=http
        firewall-cmd --permanent --add-service=https
        firewall-cmd --permanent --add-service=ssh
        firewall-cmd --reload
        log_success "Firewalld configurado."
    fi
}

# Configurar backups automáticos
setup_backups() {
    log_info "A configurar backups automáticos..."
    
    cat > /usr/local/bin/sincetur-backup.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/var/www/sincetur/backups"
DATE=$(date +%Y%m%d_%H%M%S)
DB_FILE="/var/www/sincetur/db/sincetur.db"

# Criar backup
mkdir -p $BACKUP_DIR
cp $DB_FILE $BACKUP_DIR/sincetur_$DATE.db

# Comprimir
gzip $BACKUP_DIR/sincetur_$DATE.db

# Manter apenas últimos 30 dias
find $BACKUP_DIR -name "*.gz" -mtime +30 -delete

echo "Backup criado: sincetur_$DATE.db.gz"
EOF

    chmod +x /usr/local/bin/sincetur-backup.sh
    
    # Cron job
    (crontab -l 2>/dev/null; echo "0 2 * * * /usr/local/bin/sincetur-backup.sh >> /var/www/sincetur/logs/backup.log 2>&1") | crontab -
    
    log_success "Backups configurados (diário às 02:00)"
}

# Iniciar serviço
start_service() {
    log_info "A iniciar serviço..."
    
    systemctl start sincetur
    systemctl status sincetur --no-pager
    
    log_success "Serviço iniciado."
}

# Mostrar informações finais
show_final_info() {
    DOMAIN=${1:-"sincetur.com"}
    
    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║           INSTALAÇÃO CONCLUÍDA COM SUCESSO!                  ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "🌐 Portal: ${BLUE}https://$DOMAIN${NC}"
    echo -e "📁 Directório: /var/www/sincetur"
    echo ""
    echo -e "👤 Credenciais de acesso:"
    echo -e "   Email: ${YELLOW}admin@sincetur.com${NC}"
    echo -e "   Password: ${YELLOW}admin123${NC}"
    echo ""
    echo -e "📝 Comandos úteis:"
    echo -e "   Status: ${BLUE}systemctl status sincetur${NC}"
    echo -e "   Reiniciar: ${BLUE}systemctl restart sincetur${NC}"
    echo -e "   Logs: ${BLUE}journalctl -u sincetur -f${NC}"
    echo ""
    echo -e "⚠️  IMPORTANTE: Altere a password após o primeiro acesso!"
    echo ""
}

# Menu principal
main() {
    show_banner
    
    check_root
    detect_os
    
    echo ""
    echo -e "${YELLOW}Este script irá:${NC}"
    echo "  1. Instalar dependências do sistema"
    echo "  2. Instalar Node.js e Bun"
    echo "  3. Configurar a aplicação"
    echo "  4. Configurar Nginx"
    echo "  5. Configurar SSL (opcional)"
    echo "  6. Configurar firewall"
    echo "  7. Configurar backups"
    echo ""
    
    read -p "Deseja continuar? (y/n): " -n 1 -r
    echo ""
    
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        log_info "Instalação cancelada."
        exit 0
    fi
    
    # Obter domínio
    read -p "Domínio (ex: sincetur.com): " DOMAIN
    DOMAIN=${DOMAIN:-"sincetur.com"}
    
    # Executar instalação
    install_system_dependencies
    install_nodejs
    install_bun
    create_app_user
    setup_directories
    setup_application
    set_permissions
    setup_systemd
    setup_nginx $DOMAIN
    
    read -p "Configurar SSL com Let's Encrypt? (y/n): " -n 1 -r
    echo ""
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        setup_ssl $DOMAIN
    fi
    
    setup_firewall
    setup_backups
    start_service
    
    show_final_info $DOMAIN
}

# Executar
main "$@"
