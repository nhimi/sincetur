# Sincetur Viagens e Turismo - Portal ERP

Portal completo de agência de viagens com módulos ERP para o mercado angolano.

## 📋 Módulos

| Módulo | Descrição |
|--------|-----------|
| **Tours** | Gestão de pacotes turísticos |
| **Alojamentos** | Hotéis, pousadas, resorts |
| **Voos** | Reservas de voos |
| **Autocarros** | Bilhetes de autocarro |
| **Eventos** | Gestão de eventos turísticos |
| **Vistos** | Assessoria de vistos |
| **Clientes ERP** | Gestão completa de clientes (Dolibarr-style) |
| **Contabilidade** | Plano de contas SNC Angola |
| **API B2B/B2C** | Integração com parceiros |

## 🔧 Requisitos

- Node.js 20+
- Bun
- SQLite
- Nginx (produção)

## 📥 Instalação

### Desenvolvimento

```bash
# Clone o repositório
git clone <repositório>
cd sincetur

# Instale dependências
bun install

# Configure ambiente
cp .env.example .env

# Inicialize a base de dados
bun run db:push
bun run db:seed

# Inicie o servidor
bun run dev
```

### Produção (Ubuntu/Debian)

```bash
# Torne o script executável
chmod +x install.sh

# Execute como root
sudo ./install.sh
```

## 🔐 Credenciais

| Perfil | Email | Password |
|--------|-------|----------|
| Super Admin | admin@sincetur.com | admin123 |
| Admin | gerente@sincetur.com | admin123 |
| Agente B2B | agente@parceiro.com | admin123 |
| Cliente B2C | cliente@gmail.com | admin123 |

## 📡 API Endpoints

### Clientes

```
GET    /api/clients           - Listar clientes
POST   /api/clients           - Criar cliente
GET    /api/clients/:id       - Obter cliente
PUT    /api/clients/:id       - Actualizar cliente
DELETE /api/clients/:id       - Eliminar cliente
GET    /api/clients/:id/stats - Estatísticas
GET    /api/clients/:id/bookings - Reservas
```

### Tours

```
GET    /api/tours        - Listar tours
POST   /api/tours        - Criar tour
GET    /api/tours/:id    - Obter tour
PUT    /api/tours/:id    - Actualizar tour
DELETE /api/tours/:id    - Eliminar tour
```

### Alojamentos

```
GET    /api/accommodations        - Listar alojamentos
POST   /api/accommodations        - Criar alojamento
GET    /api/accommodations/:id    - Obter alojamento
PUT    /api/accommodations/:id    - Actualizar alojamento
DELETE /api/accommodations/:id    - Eliminar alojamento
```

### Reservas

```
GET    /api/bookings        - Listar reservas
POST   /api/bookings        - Criar reserva
GET    /api/bookings/:id    - Obter reserva
PUT    /api/bookings/:id    - Actualizar reserva
```

## 🔗 Integração com Módulo Cliente

O módulo Cliente ERP integra-se com todos os outros módulos através de:

1. **User** - Clientes ligados a utilizadores do sistema
2. **Transacções** - Histórico financeiro unificado
3. **Comunicações** - Registo de todas as interacções
4. **Tarefas** - Gestão de follow-ups
5. **Documentos** - BI, Passaporte, NIF, etc.

### Funções Partilhadas

```typescript
// Estatísticas completas do cliente
import { getClientStats } from '@/lib/clients/utils';
const stats = await getClientStats(clientId);

// Todas as reservas do cliente
import { getClientBookings } from '@/lib/clients/utils';
const bookings = await getClientBookings(clientId);

// Criar transacção financeira
import { createClientTransaction } from '@/lib/clients/utils';
await createClientTransaction({
  clientId,
  type: 'DEBIT',
  category: 'tour',
  description: 'Reserva tour Luanda',
  amount: 150000,
});

// Pesquisar clientes
import { searchClients } from '@/lib/clients/utils';
const results = await searchClients('Maria');
```

## 🇦🇴 Contabilidade Angola

- Plano de Contas SNC
- IVA 14%
- IRC 25%
- Facturação electrónica
- Relatórios fiscais

## 📱 Contacto

**Sincetur Viagens e Turismo**
- Telefone: +244 922 862 963
- Email: reservas@sincetur.com
- Endereço: AVE. Hoji ya Henda, Predio 132, Vila Alice - Rangel - Luanda
- Facebook: #sincetur

## 📄 Licença

Propriedade de Sincetur Viagens e Turismo. Todos os direitos reservados.
