import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Iniciando seed da base de dados...');

  // ============================================
  // LIMPAR DADOS EXISTENTES
  // ============================================
  console.log('Limpando dados existentes...');
  await prisma.journalEntryLine.deleteMany();
  await prisma.journalEntry.deleteMany();
  await prisma.fiscalYear.deleteMany();
  await prisma.chartOfAccount.deleteMany();
  await prisma.invoiceItem.deleteMany();
  await prisma.invoice.deleteMany();
  await prisma.tax.deleteMany();
  await prisma.eventBooking.deleteMany();
  await prisma.event.deleteMany();
  await prisma.eventCategory.deleteMany();
  await prisma.flightBooking.deleteMany();
  await prisma.busTicket.deleteMany();
  await prisma.busDeparture.deleteMany();
  await prisma.busRoute.deleteMany();
  await prisma.bus.deleteMany();
  await prisma.busCompany.deleteMany();
  await prisma.visaRequest.deleteMany();
  await prisma.visaType.deleteMany();
  await prisma.visaCountry.deleteMany();
  await prisma.accommodationReview.deleteMany();
  await prisma.accommodationBooking.deleteMany();
  await prisma.room.deleteMany();
  await prisma.accommodationAmenity.deleteMany();
  await prisma.accommodation.deleteMany();
  await prisma.accommodationType.deleteMany();
  await prisma.amenity.deleteMany();
  await prisma.tourReview.deleteMany();
  await prisma.tourBooking.deleteMany();
  await prisma.tour.deleteMany();
  await prisma.tourCategory.deleteMany();
  await prisma.destination.deleteMany();
  await prisma.apiKey.deleteMany();
  await prisma.activityLog.deleteMany();
  await prisma.session.deleteMany();
  await prisma.account.deleteMany();
  await prisma.user.deleteMany();
  await prisma.systemConfig.deleteMany();

  // ============================================
  // UTILIZADORES
  // ============================================
  console.log('Criando utilizadores...');
  const hashedPassword = await bcrypt.hash('admin123', 10);
  
  const superAdmin = await prisma.user.create({
    data: {
      email: 'admin@sincetur.com',
      password: hashedPassword,
      name: 'Administrador Principal',
      phone: '+244 922 862 963',
      role: 'SUPER_ADMIN',
      emailVerified: new Date(),
    },
  });

  const admin = await prisma.user.create({
    data: {
      email: 'gerente@sincetur.com',
      password: hashedPassword,
      name: 'Gerente de Operações',
      phone: '+244 922 862 963',
      role: 'ADMIN',
      emailVerified: new Date(),
    },
  });

  const agentB2B = await prisma.user.create({
    data: {
      email: 'agente@parceiro.com',
      password: hashedPassword,
      name: 'Agente Parceiro',
      phone: '+244 922 862 963',
      role: 'AGENT_B2B',
      emailVerified: new Date(),
    },
  });

  const clientB2C = await prisma.user.create({
    data: {
      email: 'cliente@gmail.com',
      password: hashedPassword,
      name: 'Cliente Teste',
      phone: '+244 922 862 963',
      role: 'CLIENT_B2C',
      emailVerified: new Date(),
    },
  });

  // ============================================
  // CONFIGURAÇÕES DO SISTEMA
  // ============================================
  console.log('Criando configurações do sistema...');
  await prisma.systemConfig.createMany({
    data: [
      { key: 'company_name', value: 'Sincetur Viagens e Turismo', description: 'Nome da empresa' },
      { key: 'company_nif', value: '5001234567', description: 'NIF da empresa' },
      { key: 'company_address', value: 'AVE. Hoji ya Henda, Predio 132, Vila Alice - Rangel - Luanda', description: 'Endereço' },
      { key: 'company_phone', value: '+244 922 862 963', description: 'Telefone' },
      { key: 'company_email', value: 'reservas@sincetur.com', description: 'Email' },
      { key: 'company_facebook', value: '#sincetur', description: 'Facebook' },
      { key: 'currency_default', value: 'Kz', description: 'Moeda padrão' },
      { key: 'iva_rate', value: '14', description: 'Taxa IVA Angola (%)' },
    ],
  });

  // ============================================
  // DESTINOS
  // ============================================
  console.log('Criando destinos...');
  const luanda = await prisma.destination.create({
    data: {
      name: 'Luanda',
      slug: 'luanda',
      province: 'Luanda',
      country: 'Angola',
      description: 'Capital de Angola, cidade costeira vibrante com praias deslumbrantes, cultura rica e vida noturna animada.',
      latitude: -8.8390,
      longitude: 13.2894,
    },
  });

  const benguela = await prisma.destination.create({
    data: {
      name: 'Benguela',
      slug: 'benguela',
      province: 'Benguela',
      country: 'Angola',
      description: 'Cidade costeira histórica com praias paradisíacas e arquitetura colonial portuguesa.',
      latitude: -12.5763,
      longitude: 13.4056,
    },
  });

  const namibe = await prisma.destination.create({
    data: {
      name: 'Namibe',
      slug: 'namibe',
      province: 'Namíbe',
      country: 'Angola',
      description: 'Deserto do Namibe, paisagens únicas, o famoso Welwitschia mirabilis e praias desertas.',
      latitude: -15.1961,
      longitude: 12.1520,
    },
  });

  const huila = await prisma.destination.create({
    data: {
      name: 'Serra da Leba',
      slug: 'serra-da-leba',
      province: 'Huíla',
      country: 'Angola',
      description: 'Serra da Leba com suas famosas curvas, vista panorâmica espetacular e clima ameno.',
      latitude: -14.8333,
      longitude: 13.2500,
    },
  });

  const kalandula = await prisma.destination.create({
    data: {
      name: 'Quedas de Kalandula',
      slug: 'quedas-de-kalandula',
      province: 'Malanje',
      country: 'Angola',
      description: 'Quedas de Kalandula, uma das maiores cachoeiras de África com 105 metros de altura.',
      latitude: -9.0667,
      longitude: 16.0000,
    },
  });

  // ============================================
  // CATEGORIAS DE TOURS
  // ============================================
  console.log('Criando categorias de tours...');
  const culturalTour = await prisma.tourCategory.create({
    data: {
      name: 'Cultural',
      slug: 'cultural',
      description: 'Tours focados em património cultural, museus e tradições locais',
      icon: 'landmark',
      color: '#8B5CF6',
    },
  });

  const adventureTour = await prisma.tourCategory.create({
    data: {
      name: 'Aventura',
      slug: 'aventura',
      description: 'Experiências emocionantes e actividades ao ar livre',
      icon: 'mountain',
      color: '#F59E0B',
    },
  });

  const beachTour = await prisma.tourCategory.create({
    data: {
      name: 'Praia',
      slug: 'praia',
      description: 'Relaxe nas praias paradisíacas de Angola',
      icon: 'umbrella',
      color: '#06B6D4',
    },
  });

  const safariTour = await prisma.tourCategory.create({
    data: {
      name: 'Safari',
      slug: 'safari',
      description: 'Observação de vida selvagem nos parques nacionais',
      icon: 'binoculars',
      color: '#10B981',
    },
  });

  // ============================================
  // TOURS
  // ============================================
  console.log('Criando tours...');
  await prisma.tour.createMany({
    data: [
      {
        title: 'Descoberta de Luanda',
        slug: 'descoberta-de-luanda',
        description: 'Explore a vibrante capital de Angola neste tour completo de 3 dias. Visite a Fortaleza de São Miguel, o Museu Nacional de Antropologia, o Mercado do Benfica e desfrute das praias da Ilha de Luanda. Inclui alojamento em hotel 4 estrelas, todas as refeições e transporte privativo.',
        shortDescription: 'Explore a capital angolana em 3 dias inesquecíveis',
        categoryId: culturalTour.id,
        destinationId: luanda.id,
        duration: 3,
        difficulty: 'EASY',
        maxGroupSize: 12,
        priceKz: 150000,
        priceUsd: 180,
        included: JSON.stringify(['Alojamento 4 estrelas', 'Todas as refeições', 'Transporte privativo', 'Guia turístico', 'Entradas em museus']),
        notIncluded: JSON.stringify(['Bebidas alcoólicas', 'Compras pessoais', 'Gorjetas']),
        itinerary: JSON.stringify([
          { day: 1, title: 'Chegada e City Tour', activities: ['Chegada no aeroporto', 'Check-in no hotel', 'Visita à Fortaleza de São Miguel', 'Passeio pela Baía de Luanda'] },
          { day: 2, title: 'Cultura e História', activities: ['Museu Nacional de Antropologia', 'Mercado do Benfica', 'Almoço típico angolano', 'Tarde na Ilha de Luanda'] },
          { day: 3, title: 'Despedida', activities: ['Pequeno-almoço', 'Visita ao Miradouro da Lua', 'Transfer para aeroporto'] }
        ]),
        departureDates: JSON.stringify(['2024-06-15', '2024-06-22', '2024-06-29']),
        availableSeats: 10,
        isFeatured: true,
      },
      {
        title: 'Safari no Parque Nacional da Kissama',
        slug: 'safari-parque-kissama',
        description: 'Aventura inesquecível no Parque Nacional da Kissama, a apenas 70km de Luanda. Observe elefantes, palancas, girafas e diversas espécies de aves no seu habitat natural. Inclui safari diurno e noturno, alojamento em lodge e todas as refeições.',
        shortDescription: 'Experiência de safari com vida selvagem abundante',
        categoryId: safariTour.id,
        destinationId: luanda.id,
        duration: 2,
        difficulty: 'MODERATE',
        maxGroupSize: 8,
        priceKz: 200000,
        priceUsd: 240,
        included: JSON.stringify(['Alojamento em lodge', 'Todas as refeições', 'Safari diurno e noturno', 'Guia especializado', 'Transfer Luanda-Parque']),
        notIncluded: JSON.stringify(['Bebidas', 'Equipamento fotográfico', 'Seguro viagem']),
        itinerary: JSON.stringify([
          { day: 1, title: 'Chegada e Safari', activities: ['Partida de Luanda', 'Check-in no lodge', 'Safari diurno', 'Jantar e safari noturno'] },
          { day: 2, title: 'Manhã na Savana', activities: ['Safari ao amanhecer', 'Pequeno-almoço', 'Retorno a Luanda'] }
        ]),
        departureDates: JSON.stringify(['2024-06-14', '2024-06-21', '2024-06-28']),
        availableSeats: 8,
        isFeatured: true,
      },
      {
        title: 'Maravilhas do Namibe',
        slug: 'maravilhas-do-namibe',
        description: 'Descubra a beleza surreal do deserto do Namibe. Visite as formações rochosas do Arco, o Parque Nacional do Iona, a Welwitschia mirabilis - planta milenar do deserto - e desfrute de praias desertas. Uma experiência única de 4 dias.',
        shortDescription: 'Deserto, praias desertas e paisagens lunares',
        categoryId: adventureTour.id,
        destinationId: namibe.id,
        duration: 4,
        difficulty: 'MODERATE',
        maxGroupSize: 10,
        priceKz: 280000,
        priceUsd: 340,
        included: JSON.stringify(['Alojamento em hotel e acampamento', 'Todas as refeições', 'Veículo 4x4', 'Guia especializado', 'Equipamento de acampamento']),
        notIncluded: JSON.stringify(['Voo para Namibe', 'Bebidas', 'Equipamento pessoal']),
        itinerary: JSON.stringify([
          { day: 1, title: 'Chegada ao Namibe', activities: ['Chegada ao aeroporto', 'Transfer para hotel', 'Passeio pela cidade', 'Jantar de frutos do mar'] },
          { day: 2, title: 'Deserto e Welwitschia', activities: ['Viagem ao deserto', 'Observação da Welwitschia mirabilis', 'Piquenique no deserto', 'Acampamento sob as estrelas'] },
          { day: 3, title: 'Parque Nacional do Iona', activities: ['Exploração do parque', 'Praias desertas', 'Formações rochosas', 'Retorno ao hotel'] },
          { day: 4, title: 'Despedida', activities: ['Pequeno-almoço', 'Compra de artesanato', 'Transfer para aeroporto'] }
        ]),
        departureDates: JSON.stringify(['2024-06-20', '2024-06-27', '2024-07-04']),
        availableSeats: 6,
        isFeatured: true,
      },
      {
        title: 'Quedas de Kalandula e Pungo Andongo',
        slug: 'quedas-kalandula-pungo-andongo',
        description: 'Conheça uma das maiores cachoeiras de África! As Quedas de Kalandula impressionam com seus 105 metros de altura. Visite também as Pedras Negras de Pungo Andongo, formações geológicas misteriosas com significado histórico profundo.',
        shortDescription: 'Cachoeiras impressionantes e formações geológicas misteriosas',
        categoryId: adventureTour.id,
        destinationId: kalandula.id,
        duration: 3,
        difficulty: 'EASY',
        maxGroupSize: 15,
        priceKz: 180000,
        priceUsd: 220,
        included: JSON.stringify(['Alojamento em hotel', 'Todas as refeições', 'Transporte', 'Guia', 'Entradas']),
        notIncluded: JSON.stringify(['Bebidas', 'Compras pessoais']),
        itinerary: JSON.stringify([
          { day: 1, title: 'Viagem para Malanje', activities: ['Partida de Luanda', 'Paragem no Dondo', 'Chegada a Malanje', 'Jantar típico'] },
          { day: 2, title: 'Quedas de Kalandula', activities: ['Visita às quedas', 'Caminhada pelas margens', 'Almoço com vista', 'Tarde livre'] },
          { day: 3, title: 'Pungo Andongo', activities: ['Visita às Pedras Negras', 'História do Reino Ndongo', 'Retorno a Luanda'] }
        ]),
        departureDates: JSON.stringify(['2024-06-16', '2024-06-23', '2024-06-30']),
        availableSeats: 12,
      },
      {
        title: 'Praias de Benguela',
        slug: 'praias-de-benguela',
        description: 'Relaxe nas mais belas praias de Benguela. Baía Azul, Caota e Lobito oferecem areias brancas e águas cristalinas. Inclui visita à cidade histórica de Benguela com sua arquitetura colonial.',
        shortDescription: 'Sol, praia e história colonial',
        categoryId: beachTour.id,
        destinationId: benguela.id,
        duration: 4,
        difficulty: 'EASY',
        maxGroupSize: 20,
        priceKz: 220000,
        priceUsd: 270,
        included: JSON.stringify(['Alojamento em hotel frente ao mar', 'Pequeno-almoço', 'Transporte', 'Guia', 'Actividades de praia']),
        notIncluded: JSON.stringify(['Almoços e jantares', 'Bebidas', 'Desportos aquáticos']),
        itinerary: JSON.stringify([
          { day: 1, title: 'Chegada a Benguela', activities: ['Voo de Luanda', 'City tour', 'Check-in no hotel', 'Pôr do sol na praia'] },
          { day: 2, title: 'Baía Azul', activities: ['Manhã de praia', 'Mergulho livre', 'Almoço de frutos do mar', 'Tarde relaxante'] },
          { day: 3, title: 'Lobito e Caota', activities: ['Visita ao Lobito', 'Praia da Caota', 'Passeio de barco'] },
          { day: 4, title: 'Despedida', activities: ['Pequeno-almoço', 'Tempo livre', 'Transfer para aeroporto'] }
        ]),
        departureDates: JSON.stringify(['2024-06-17', '2024-06-24', '2024-07-01']),
        availableSeats: 15,
      },
      {
        title: 'Serra da Leba e Lubango',
        slug: 'serra-da-leba-lubango',
        description: 'Explore as paisagens deslumbrantes da Huíla. A famosa Serra da Leba com suas curvas espetaculares, a cidade de Lubango, a Tunda Vala Fissure e o Cristo Rei. Clima ameno e vistas incríveis garantidas.',
        shortDescription: 'Paisagens de cortar a respiração na Huíla',
        categoryId: adventureTour.id,
        destinationId: huila.id,
        duration: 4,
        difficulty: 'MODERATE',
        maxGroupSize: 12,
        priceKz: 250000,
        priceUsd: 300,
        included: JSON.stringify(['Alojamento em hotel', 'Todas as refeições', 'Transporte 4x4', 'Guia', 'Entradas']),
        notIncluded: JSON.stringify(['Voo para Lubango', 'Bebidas', 'Compras']),
        itinerary: JSON.stringify([
          { day: 1, title: 'Chegada a Lubango', activities: ['Voo de Luanda', 'City tour', 'Visita ao Cristo Rei', 'Jantar típico'] },
          { day: 2, title: 'Serra da Leba', activities: ['Descida da serra', 'Paragens fotográficas', 'Picnic', 'Retorno ao hotel'] },
          { day: 3, title: 'Tunda Vala', activities: ['Visita à fissura', 'Caminhada', 'Observação de aves', 'Churrasco'] },
          { day: 4, title: 'Despedida', activities: ['Mercado municipal', 'Artesanato', 'Transfer para aeroporto'] }
        ]),
        departureDates: JSON.stringify(['2024-06-18', '2024-06-25', '2024-07-02']),
        availableSeats: 10,
      },
    ],
  });

  // ============================================
  // TIPOS DE ALOJAMENTO
  // ============================================
  console.log('Criando tipos de alojamento...');
  const hotelType = await prisma.accommodationType.create({
    data: { name: 'Hotel', slug: 'hotel' },
  });
  const pousadaType = await prisma.accommodationType.create({
    data: { name: 'Pousada', slug: 'pousada' },
  });
  const resortType = await prisma.accommodationType.create({
    data: { name: 'Resort', slug: 'resort' },
  });
  const apartmentType = await prisma.accommodationType.create({
    data: { name: 'Apartamento', slug: 'apartamento' },
  });

  // ============================================
  // COMODIDADES
  // ============================================
  console.log('Criando comodidades...');
  const amenities = await Promise.all([
    prisma.amenity.create({ data: { name: 'Wi-Fi Gratuito', icon: 'wifi', category: 'general' } }),
    prisma.amenity.create({ data: { name: 'Ar Condicionado', icon: 'wind', category: 'room' } }),
    prisma.amenity.create({ data: { name: 'Piscina', icon: 'waves', category: 'general' } }),
    prisma.amenity.create({ data: { name: 'Restaurante', icon: 'utensils', category: 'general' } }),
    prisma.amenity.create({ data: { name: 'Estacionamento', icon: 'car', category: 'general' } }),
    prisma.amenity.create({ data: { name: 'TV por Cabo', icon: 'tv', category: 'room' } }),
    prisma.amenity.create({ data: { name: 'Serviço de Quartos', icon: 'bell', category: 'service' } }),
    prisma.amenity.create({ data: { name: 'Ginásio', icon: 'dumbbell', category: 'general' } }),
    prisma.amenity.create({ data: { name: 'Spa', icon: 'sparkles', category: 'service' } }),
    prisma.amenity.create({ data: { name: 'Bar', icon: 'glass-water', category: 'general' } }),
    prisma.amenity.create({ data: { name: 'Vista Mar', icon: 'sea', category: 'room' } }),
    prisma.amenity.create({ data: { name: 'Pequeno-almoço incluído', icon: 'coffee', category: 'service' } }),
  ]);

  // ============================================
  // ALOJAMENTOS
  // ============================================
  console.log('Criando alojamentos...');
  const hotelContinental = await prisma.accommodation.create({
    data: {
      name: 'Hotel Continental Luanda',
      slug: 'hotel-continental-luanda',
      description: 'Hotel 5 estrelas localizado no coração de Luanda, com vista panorâmica para a baía. Quartos luxuosos, restaurantes gourmet, spa e centro de conferências.',
      shortDescription: 'Luxo 5 estrelas no centro de Luanda',
      typeId: hotelType.id,
      destinationId: luanda.id,
      address: 'Rua da Missão, 123, Luanda',
      stars: 5,
      totalRooms: 150,
      priceFromKz: 45000,
      priceFromUsd: 55,
      checkInTime: '14:00',
      checkOutTime: '12:00',
      cancellationPolicy: 'Cancelamento gratuito até 48 horas antes do check-in',
      isFeatured: true,
    },
  });

  const pousadaNamibe = await prisma.accommodation.create({
    data: {
      name: 'Pousada do Deserto',
      slug: 'pousada-do-deserto',
      description: 'Pousada charmosa no Namibe, inspirada na arquitetura local. Quartos decorados com arte angolana, restaurante com cozinha regional e piscina com vista para o deserto.',
      shortDescription: 'Charme autêntico no deserto',
      typeId: pousadaType.id,
      destinationId: namibe.id,
      address: 'Estrada do Iona, Km 10, Namibe',
      stars: 4,
      totalRooms: 20,
      priceFromKz: 25000,
      priceFromUsd: 30,
      isFeatured: true,
    },
  });

  const resortBenguela = await prisma.accommodation.create({
    data: {
      name: 'Resort Baía Azul',
      slug: 'resort-baia-azul',
      description: 'Resort frente ao mar em Benguela com praia privativa, 3 restaurantes, spa completo, centro de mergulho e atividades para toda a família.',
      shortDescription: 'Paraíso à beira-mar em Benguela',
      typeId: resortType.id,
      destinationId: benguela.id,
      address: 'Praia da Baía Azul, Benguela',
      stars: 5,
      totalRooms: 80,
      priceFromKz: 55000,
      priceFromUsd: 65,
      checkInTime: '15:00',
      checkOutTime: '11:00',
      isFeatured: true,
    },
  });

  const hotelLubango = await prisma.accommodation.create({
    data: {
      name: 'Hotel Serra da Leba',
      slug: 'hotel-serra-da-leba',
      description: 'Hotel com vista espetacular para a Serra da Leba. Quarto com varanda, restaurante panorâmico, jardins e acesso fácil às principais atrações.',
      shortDescription: 'Vistas incríveis da Serra da Leba',
      typeId: hotelType.id,
      destinationId: huila.id,
      address: 'Estrada da Serra, Lubango',
      stars: 4,
      totalRooms: 45,
      priceFromKz: 30000,
      priceFromUsd: 36,
    },
  });

  const lodgeKissama = await prisma.accommodation.create({
    data: {
      name: 'Kissama Lodge',
      slug: 'kissama-lodge',
      description: 'Lodge ecológico dentro do Parque Nacional da Kissama. Bungalows de madeira com vista para a savana, restaurante com produtos locais e safaris diários.',
      shortDescription: 'Experiência de safari autêntica',
      typeId: pousadaType.id,
      destinationId: luanda.id,
      address: 'Parque Nacional da Kissama',
      stars: 3,
      totalRooms: 15,
      priceFromKz: 35000,
      priceFromUsd: 42,
    },
  });

  // Adicionar comodidades aos alojamentos
  await prisma.accommodationAmenity.createMany({
    data: [
      { accommodationId: hotelContinental.id, amenityId: amenities[0].id }, // Wi-Fi
      { accommodationId: hotelContinental.id, amenityId: amenities[1].id }, // AC
      { accommodationId: hotelContinental.id, amenityId: amenities[2].id }, // Piscina
      { accommodationId: hotelContinental.id, amenityId: amenities[3].id }, // Restaurante
      { accommodationId: hotelContinental.id, amenityId: amenities[4].id }, // Estacionamento
      { accommodationId: hotelContinental.id, amenityId: amenities[5].id }, // TV
      { accommodationId: hotelContinental.id, amenityId: amenities[6].id }, // Serviço de quartos
      { accommodationId: hotelContinental.id, amenityId: amenities[7].id }, // Ginásio
      { accommodationId: hotelContinental.id, amenityId: amenities[8].id }, // Spa
      { accommodationId: hotelContinental.id, amenityId: amenities[9].id }, // Bar
      { accommodationId: hotelContinental.id, amenityId: amenities[11].id }, // Pequeno-almoço
      { accommodationId: pousadaNamibe.id, amenityId: amenities[0].id },
      { accommodationId: pousadaNamibe.id, amenityId: amenities[1].id },
      { accommodationId: pousadaNamibe.id, amenityId: amenities[3].id },
      { accommodationId: pousadaNamibe.id, amenityId: amenities[2].id },
      { accommodationId: resortBenguela.id, amenityId: amenities[0].id },
      { accommodationId: resortBenguela.id, amenityId: amenities[1].id },
      { accommodationId: resortBenguela.id, amenityId: amenities[2].id },
      { accommodationId: resortBenguela.id, amenityId: amenities[3].id },
      { accommodationId: resortBenguela.id, amenityId: amenities[4].id },
      { accommodationId: resortBenguela.id, amenityId: amenities[10].id }, // Vista mar
      { accommodationId: resortBenguela.id, amenityId: amenities[11].id },
      { accommodationId: hotelLubango.id, amenityId: amenities[0].id },
      { accommodationId: hotelLubango.id, amenityId: amenities[1].id },
      { accommodationId: hotelLubango.id, amenityId: amenities[3].id },
      { accommodationId: lodgeKissama.id, amenityId: amenities[3].id },
      { accommodationId: lodgeKissama.id, amenityId: amenities[4].id },
    ],
  });

  // ============================================
  // QUARTOS
  // ============================================
  console.log('Criando quartos...');
  await prisma.room.createMany({
    data: [
      { accommodationId: hotelContinental.id, name: 'Quarto Standard', description: 'Quarto confortável com cama de casal', maxAdults: 2, maxChildren: 1, totalRooms: 50, priceKz: 45000, priceUsd: 55 },
      { accommodationId: hotelContinental.id, name: 'Quarto Superior', description: 'Quarto espaçoso com vista cidade', maxAdults: 2, maxChildren: 2, totalRooms: 40, priceKz: 65000, priceUsd: 80 },
      { accommodationId: hotelContinental.id, name: 'Suite Presidencial', description: 'Suite de luxo com sala de estar', maxAdults: 4, maxChildren: 2, totalRooms: 10, priceKz: 150000, priceUsd: 180 },
      { accommodationId: pousadaNamibe.id, name: 'Bungalow Standard', description: 'Bungalow acolhedor com vista deserto', maxAdults: 2, totalRooms: 10, priceKz: 25000, priceUsd: 30 },
      { accommodationId: pousadaNamibe.id, name: 'Bungalow Família', description: 'Bungalow espaçoso para famílias', maxAdults: 4, maxChildren: 2, totalRooms: 5, priceKz: 40000, priceUsd: 48 },
      { accommodationId: resortBenguela.id, name: 'Quarto Vista Mar', description: 'Quarto com vista panorâmica para o mar', maxAdults: 2, totalRooms: 30, priceKz: 55000, priceUsd: 65 },
      { accommodationId: resortBenguela.id, name: 'Suite Família', description: 'Suite ampla com quarto separado', maxAdults: 4, maxChildren: 2, totalRooms: 20, priceKz: 85000, priceUsd: 100 },
      { accommodationId: hotelLubango.id, name: 'Quarto Standard', description: 'Quarto confortável', maxAdults: 2, totalRooms: 25, priceKz: 30000, priceUsd: 36 },
      { accommodationId: hotelLubango.id, name: 'Quarto Vista Serra', description: 'Quarto com varanda e vista', maxAdults: 2, totalRooms: 15, priceKz: 40000, priceUsd: 48 },
      { accommodationId: lodgeKissama.id, name: 'Bungalow Safari', description: 'Bungalow com vista savana', maxAdults: 2, totalRooms: 10, priceKz: 35000, priceUsd: 42 },
      { accommodationId: lodgeKissama.id, name: 'Bungalow Família', description: 'Bungalow para famílias', maxAdults: 4, maxChildren: 2, totalRooms: 5, priceKz: 55000, priceUsd: 65 },
    ],
  });

  // ============================================
  // PAÍSES PARA VISTOS
  // ============================================
  console.log('Criando países para vistos...');
  const portugal = await prisma.visaCountry.create({
    data: {
      name: 'Portugal',
      code: 'PT',
      requiresVisa: true,
      processingDays: 15,
      documents: JSON.stringify(['Passaporte válido', 'Comprovativo de meios de subsistência', 'Seguro viagem', 'Reserva de hotel', 'Bilhete de avião', 'Fotografias 3x4', 'Carta de motivação', 'Comprovativo de emprego']),
    },
  });

  const brasil = await prisma.visaCountry.create({
    data: {
      name: 'Brasil',
      code: 'BR',
      requiresVisa: true,
      processingDays: 10,
      documents: JSON.stringify(['Passaporte válido', 'Formulário de requerimento', 'Fotografias 3x4', 'Comprovativo de rendimentos', 'Reserva de hotel', 'Itinerário de viagem']),
    },
  });

  const eua = await prisma.visaCountry.create({
    data: {
      name: 'Estados Unidos',
      code: 'US',
      requiresVisa: true,
      processingDays: 30,
      documents: JSON.stringify(['Passaporte válido', 'DS-160', 'Foto digital', 'Comprovativo de pagamento', 'Carta de emprego', 'Extratos bancários', 'Agendamento de entrevista']),
    },
  });

  const franca = await prisma.visaCountry.create({
    data: {
      name: 'França',
      code: 'FR',
      requiresVisa: true,
      processingDays: 20,
      documents: JSON.stringify(['Passaporte válido', 'Formulário Schengen', 'Fotografias', 'Seguro viagem', 'Comprovativo de alojamento', 'Comprovativo de meios', 'Itinerário']),
    },
  });

  const africaSul = await prisma.visaCountry.create({
    data: {
      name: 'África do Sul',
      code: 'ZA',
      requiresVisa: true,
      processingDays: 7,
      documents: JSON.stringify(['Passaporte válido', 'Formulário BI-84', 'Fotografias', 'Comprovativo financeiro', 'Itinerário', 'Reserva de hotel']),
    },
  });

  // ============================================
  // TIPOS DE VISTO
  // ============================================
  console.log('Criando tipos de visto...');
  const vistoTurismo = await prisma.visaType.create({
    data: { name: 'Visto de Turismo', slug: 'turismo', description: 'Para viagens de lazer e turismo' },
  });
  const vistoNegocios = await prisma.visaType.create({
    data: { name: 'Visto de Negócios', slug: 'negocios', description: 'Para reuniões, conferências e actividades comerciais' },
  });
  const vistoEstudo = await prisma.visaType.create({
    data: { name: 'Visto de Estudo', slug: 'estudo', description: 'Para estudos em instituições estrangeiras' },
  });
  const vistoTrabalho = await prisma.visaType.create({
    data: { name: 'Visto de Trabalho', slug: 'trabalho', description: 'Para trabalho em empresas estrangeiras' },
  });

  // ============================================
  // EMPRESAS DE AUTOCARRO
  // ============================================
  console.log('Criando empresas de autocarro...');
  const macon = await prisma.busCompany.create({
    data: {
      name: 'MACON',
      slug: 'macon',
      phone: '+244 923 111 222',
      email: 'info@macon.co.ao',
    },
  });

  const angoAuto = await prisma.busCompany.create({
    data: {
      name: 'Ango Auto',
      slug: 'ango-auto',
      phone: '+244 923 333 444',
      email: 'reservas@angoauto.co.ao',
    },
  });

  // ============================================
  // AUTOCARROS
  // ============================================
  console.log('Criando autocarros...');
  const bus1 = await prisma.bus.create({
    data: { companyId: macon.id, plateNumber: 'LD-12-34-AB', model: 'Volvo 9700', totalSeats: 44, seatType: 'EXECUTIVE', amenities: JSON.stringify(['Wi-Fi', 'Ar condicionado', 'TV', 'Sanitário']) },
  });
  const bus2 = await prisma.bus.create({
    data: { companyId: macon.id, plateNumber: 'LD-56-78-CD', model: 'Scania K410', totalSeats: 44, seatType: 'EXECUTIVE', amenities: JSON.stringify(['Wi-Fi', 'Ar condicionado', 'TV', 'Sanitário']) },
  });
  const bus3 = await prisma.bus.create({
    data: { companyId: angoAuto.id, plateNumber: 'BG-11-22-EF', model: 'Mercedes O500', totalSeats: 48, seatType: 'STANDARD', amenities: JSON.stringify(['Ar condicionado', 'TV']) },
  });

  // ============================================
  // ROTAS DE AUTOCARRO
  // ============================================
  console.log('Criando rotas de autocarro...');
  const rotaLuandaBenguela = await prisma.busRoute.create({
    data: {
      companyId: macon.id,
      originId: luanda.id,
      destinationId: benguela.id,
      name: 'Luanda - Benguela',
      distance: 650,
      duration: 720,
      priceKz: 8000,
      priceUsd: 10,
    },
  });

  const rotaLuandaLubango = await prisma.busRoute.create({
    data: {
      companyId: macon.id,
      originId: luanda.id,
      destinationId: huila.id,
      name: 'Luanda - Lubango',
      distance: 1000,
      duration: 1080,
      priceKz: 12000,
      priceUsd: 15,
    },
  });

  const rotaLuandaNamibe = await prisma.busRoute.create({
    data: {
      companyId: angoAuto.id,
      originId: luanda.id,
      destinationId: namibe.id,
      name: 'Luanda - Namibe',
      distance: 1200,
      duration: 1260,
      priceKz: 15000,
      priceUsd: 18,
    },
  });

  // ============================================
  // PARTIDAS DE AUTOCARRO
  // ============================================
  console.log('Criando partidas de autocarro...');
  await prisma.busDeparture.createMany({
    data: [
      { routeId: rotaLuandaBenguela.id, busId: bus1.id, departureTime: '06:00', arrivalTime: '18:00', daysOfWeek: JSON.stringify([1, 2, 3, 4, 5, 6, 0]), availableSeats: 44 },
      { routeId: rotaLuandaBenguela.id, busId: bus2.id, departureTime: '20:00', arrivalTime: '08:00', daysOfWeek: JSON.stringify([1, 3, 5, 0]), availableSeats: 44 },
      { routeId: rotaLuandaLubango.id, busId: bus1.id, departureTime: '05:00', arrivalTime: '23:00', daysOfWeek: JSON.stringify([1, 3, 5]), availableSeats: 44 },
      { routeId: rotaLuandaLubango.id, busId: bus2.id, departureTime: '18:00', arrivalTime: '12:00', daysOfWeek: JSON.stringify([2, 4, 6]), availableSeats: 44 },
      { routeId: rotaLuandaNamibe.id, busId: bus3.id, departureTime: '04:00', arrivalTime: '01:00', daysOfWeek: JSON.stringify([2, 5, 0]), availableSeats: 48 },
    ],
  });

  // ============================================
  // CATEGORIAS DE EVENTOS
  // ============================================
  console.log('Criando categorias de eventos...');
  const festivalCat = await prisma.eventCategory.create({
    data: { name: 'Festival', slug: 'festival', description: 'Festivais culturais e musicais' },
  });
  const conferenciaCat = await prisma.eventCategory.create({
    data: { name: 'Conferência', slug: 'conferencia', description: 'Congressos e conferências profissionais' },
  });
  const exposicaoCat = await prisma.eventCategory.create({
    data: { name: 'Exposição', slug: 'exposicao', description: 'Exposições de arte, ciência e tecnologia' },
  });
  const desportoCat = await prisma.eventCategory.create({
    data: { name: 'Desporto', slug: 'desporto', description: 'Eventos desportivos' },
  });

  // ============================================
  // EVENTOS
  // ============================================
  console.log('Criando eventos...');
  await prisma.event.createMany({
    data: [
      {
        title: 'Festival da Capulana',
        slug: 'festival-da-capulana',
        description: 'Celebração da cultura angolana com música tradicional, dança, gastronomia e artesanato. O maior festival cultural de Angola que reúne artistas de todo o país.',
        shortDescription: 'Maior festival cultural de Angola',
        categoryId: festivalCat.id,
        destinationId: luanda.id,
        venue: 'Parque Indígena',
        address: 'Ilha de Luanda',
        startDate: new Date('2024-08-15'),
        endDate: new Date('2024-08-18'),
        capacity: 10000,
        availableSeats: 7500,
        priceKz: 5000,
        priceUsd: 6,
        isFeatured: true,
      },
      {
        title: 'Luanda International Business Summit',
        slug: 'luanda-business-summit',
        description: 'Conferência internacional de negócios que reúne empresários, investidores e governos para discutir oportunidades em Angola. Networking, painéis e exposição comercial.',
        shortDescription: 'Conferência internacional de negócios',
        categoryId: conferenciaCat.id,
        destinationId: luanda.id,
        venue: 'Centro de Conferências de Talatona',
        address: 'Talatona, Luanda',
        startDate: new Date('2024-09-10'),
        endDate: new Date('2024-09-12'),
        capacity: 2000,
        availableSeats: 1500,
        priceKz: 25000,
        priceUsd: 30,
        isFeatured: true,
      },
      {
        title: 'Meia Maratona de Luanda',
        slug: 'meia-maratona-luanda',
        description: 'Corrida anual pelas ruas de Luanda com percursos de 21km, 10km e 5km. Participe nesta celebração do desporto angolano.',
        shortDescription: 'Corrida anual pela cidade de Luanda',
        categoryId: desportoCat.id,
        destinationId: luanda.id,
        venue: 'Marginal de Luanda',
        address: 'Baía de Luanda',
        startDate: new Date('2024-10-20'),
        endDate: new Date('2024-10-20'),
        capacity: 5000,
        availableSeats: 3500,
        priceKz: 2000,
        priceUsd: 2.5,
      },
      {
        title: 'Exposição de Arte Contemporânea Angolana',
        slug: 'exposicao-arte-contemporanea',
        description: 'Exposição dos melhores artistas plásticos angolanos contemporâneos. Pintura, escultura, fotografia e instalações que refletem a identidade cultural angolana.',
        shortDescription: 'Melhor da arte contemporânea angolana',
        categoryId: exposicaoCat.id,
        destinationId: luanda.id,
        venue: 'Museu Nacional de Antropologia',
        address: 'Luanda',
        startDate: new Date('2024-07-01'),
        endDate: new Date('2024-08-31'),
        capacity: 500,
        availableSeats: 500,
        priceKz: 1000,
        priceUsd: 1.2,
      },
    ],
  });

  // ============================================
  // PLANO DE CONTAS SNC ANGOLA
  // ============================================
  console.log('Criando Plano de Contas SNC Angola...');
  
  // Classe 1 - Meios Financeiros
  const conta11 = await prisma.chartOfAccount.create({
    data: { code: '11', name: 'Caixa', accountType: 'ASSET', normalBalance: 'DEBIT', level: 1 },
  });
  await prisma.chartOfAccount.create({
    data: { code: '111', name: 'Caixa - Tesouraria', accountType: 'ASSET', normalBalance: 'DEBIT', level: 2, parentId: conta11.id },
  });

  const conta12 = await prisma.chartOfAccount.create({
    data: { code: '12', name: 'Depósitos Bancários', accountType: 'ASSET', normalBalance: 'DEBIT', level: 1 },
  });
  await prisma.chartOfAccount.createMany({
    data: [
      { code: '121', name: 'Depósitos à Ordem', accountType: 'ASSET', normalBalance: 'DEBIT', level: 2, parentId: conta12.id },
      { code: '122', name: 'Depósitos a Prazo', accountType: 'ASSET', normalBalance: 'DEBIT', level: 2, parentId: conta12.id },
    ],
  });

  // Classe 2 - Terceiros
  const conta21 = await prisma.chartOfAccount.create({
    data: { code: '21', name: 'Clientes', accountType: 'ASSET', normalBalance: 'DEBIT', level: 1 },
  });
  await prisma.chartOfAccount.createMany({
    data: [
      { code: '211', name: 'Clientes - C/C', accountType: 'ASSET', normalBalance: 'DEBIT', level: 2, parentId: conta21.id },
      { code: '212', name: 'Clientes - Títulos a Receber', accountType: 'ASSET', normalBalance: 'DEBIT', level: 2, parentId: conta21.id },
      { code: '213', name: 'Clientes Duvidosos', accountType: 'ASSET', normalBalance: 'DEBIT', level: 2, parentId: conta21.id },
    ],
  });

  const conta22 = await prisma.chartOfAccount.create({
    data: { code: '22', name: 'Fornecedores', accountType: 'LIABILITY', normalBalance: 'CREDIT', level: 1 },
  });
  await prisma.chartOfAccount.createMany({
    data: [
      { code: '221', name: 'Fornecedores - C/C', accountType: 'LIABILITY', normalBalance: 'CREDIT', level: 2, parentId: conta22.id },
      { code: '222', name: 'Fornecedores - Títulos a Pagar', accountType: 'LIABILITY', normalBalance: 'CREDIT', level: 2, parentId: conta22.id },
    ],
  });

  const conta24 = await prisma.chartOfAccount.create({
    data: { code: '24', name: 'Estado e Outros Entes Públicos', accountType: 'LIABILITY', normalBalance: 'CREDIT', level: 1 },
  });
  await prisma.chartOfAccount.createMany({
    data: [
      { code: '241', name: 'IVA', accountType: 'LIABILITY', normalBalance: 'CREDIT', level: 2, parentId: conta24.id },
      { code: '242', name: 'Retenções de Impostos', accountType: 'LIABILITY', normalBalance: 'CREDIT', level: 2, parentId: conta24.id },
      { code: '243', name: 'IRC', accountType: 'LIABILITY', normalBalance: 'CREDIT', level: 2, parentId: conta24.id },
    ],
  });

  // Classe 3 - Inventários e Activos Biológicos
  const conta3 = await prisma.chartOfAccount.create({
    data: { code: '3', name: 'Inventários', accountType: 'ASSET', normalBalance: 'DEBIT', level: 1 },
  });
  await prisma.chartOfAccount.createMany({
    data: [
      { code: '31', name: 'Mercadorias', accountType: 'ASSET', normalBalance: 'DEBIT', level: 2, parentId: conta3.id },
      { code: '32', name: 'Matérias-primas', accountType: 'ASSET', normalBalance: 'DEBIT', level: 2, parentId: conta3.id },
      { code: '36', name: 'Produtos e Trabalhos em Curso', accountType: 'ASSET', normalBalance: 'DEBIT', level: 2, parentId: conta3.id },
    ],
  });

  // Classe 4 - Investimentos
  const conta4 = await prisma.chartOfAccount.create({
    data: { code: '4', name: 'Investimentos', accountType: 'ASSET', normalBalance: 'DEBIT', level: 1 },
  });
  await prisma.chartOfAccount.createMany({
    data: [
      { code: '41', name: 'Imobilizado Intangível', accountType: 'ASSET', normalBalance: 'DEBIT', level: 2, parentId: conta4.id },
      { code: '42', name: 'Imobilizado Corpóreo', accountType: 'ASSET', normalBalance: 'DEBIT', level: 2, parentId: conta4.id },
      { code: '43', name: 'Imobilizado em Curso', accountType: 'ASSET', normalBalance: 'DEBIT', level: 2, parentId: conta4.id },
      { code: '44', name: 'Investimentos Financeiros', accountType: 'ASSET', normalBalance: 'DEBIT', level: 2, parentId: conta4.id },
    ],
  });

  // Classe 5 - Capital, Reservas e Resultados
  const conta5 = await prisma.chartOfAccount.create({
    data: { code: '5', name: 'Capital e Reservas', accountType: 'EQUITY', normalBalance: 'CREDIT', level: 1 },
  });
  await prisma.chartOfAccount.createMany({
    data: [
      { code: '51', name: 'Capital', accountType: 'EQUITY', normalBalance: 'CREDIT', level: 2, parentId: conta5.id },
      { code: '52', name: 'Acções/Ações Próprias', accountType: 'EQUITY', normalBalance: 'DEBIT', level: 2, parentId: conta5.id },
      { code: '53', name: 'Reservas', accountType: 'EQUITY', normalBalance: 'CREDIT', level: 2, parentId: conta5.id },
      { code: '54', name: 'Resultados Transitados', accountType: 'EQUITY', normalBalance: 'CREDIT', level: 2, parentId: conta5.id },
      { code: '55', name: 'Resultados do Exercício', accountType: 'EQUITY', normalBalance: 'CREDIT', level: 2, parentId: conta5.id },
    ],
  });

  // Classe 6 - Gastos/Despesas
  const conta6 = await prisma.chartOfAccount.create({
    data: { code: '6', name: 'Gastos', accountType: 'EXPENSE', normalBalance: 'DEBIT', level: 1 },
  });
  await prisma.chartOfAccount.createMany({
    data: [
      { code: '61', name: 'Custo das Mercadorias Vendidas', accountType: 'EXPENSE', normalBalance: 'DEBIT', level: 2, parentId: conta6.id },
      { code: '62', name: 'Fornecimentos e Serviços Externos', accountType: 'EXPENSE', normalBalance: 'DEBIT', level: 2, parentId: conta6.id },
      { code: '63', name: 'Gastos com o Pessoal', accountType: 'EXPENSE', normalBalance: 'DEBIT', level: 2, parentId: conta6.id },
      { code: '64', name: 'Gastos de Depreciação', accountType: 'EXPENSE', normalBalance: 'DEBIT', level: 2, parentId: conta6.id },
      { code: '65', name: 'Perdas por Imparidades', accountType: 'EXPENSE', normalBalance: 'DEBIT', level: 2, parentId: conta6.id },
      { code: '66', name: 'Gastos de Financiamento', accountType: 'EXPENSE', normalBalance: 'DEBIT', level: 2, parentId: conta6.id },
      { code: '67', name: 'Gastos/Perdas Extraordinários', accountType: 'EXPENSE', normalBalance: 'DEBIT', level: 2, parentId: conta6.id },
    ],
  });

  // Classe 7 - Rendimentos/Receitas
  const conta7 = await prisma.chartOfAccount.create({
    data: { code: '7', name: 'Rendimentos', accountType: 'REVENUE', normalBalance: 'CREDIT', level: 1 },
  });
  await prisma.chartOfAccount.createMany({
    data: [
      { code: '71', name: 'Vendas', accountType: 'REVENUE', normalBalance: 'CREDIT', level: 2, parentId: conta7.id },
      { code: '72', name: 'Serviços Prestados', accountType: 'REVENUE', normalBalance: 'CREDIT', level: 2, parentId: conta7.id },
      { code: '73', name: 'Variação nos Inventários', accountType: 'REVENUE', normalBalance: 'CREDIT', level: 2, parentId: conta7.id },
      { code: '74', name: 'Trabalhos para a Própria Entidade', accountType: 'REVENUE', normalBalance: 'CREDIT', level: 2, parentId: conta7.id },
      { code: '75', name: 'Subsídios à Exploração', accountType: 'REVENUE', normalBalance: 'CREDIT', level: 2, parentId: conta7.id },
      { code: '76', name: 'Reversões', accountType: 'REVENUE', normalBalance: 'CREDIT', level: 2, parentId: conta7.id },
      { code: '77', name: 'Rendimentos/Ganhos Extraordinários', accountType: 'REVENUE', normalBalance: 'CREDIT', level: 2, parentId: conta7.id },
    ],
  });

  // Classe 8 - Resultados
  const conta8 = await prisma.chartOfAccount.create({
    data: { code: '8', name: 'Resultados', accountType: 'EQUITY', normalBalance: 'CREDIT', level: 1 },
  });
  await prisma.chartOfAccount.createMany({
    data: [
      { code: '81', name: 'Resultados Operacionais', accountType: 'EQUITY', normalBalance: 'CREDIT', level: 2, parentId: conta8.id },
      { code: '82', name: 'Resultados Financeiros', accountType: 'EQUITY', normalBalance: 'CREDIT', level: 2, parentId: conta8.id },
      { code: '83', name: 'Resultados Correntes', accountType: 'EQUITY', normalBalance: 'CREDIT', level: 2, parentId: conta8.id },
      { code: '84', name: 'Resultados Extraordinários', accountType: 'EQUITY', normalBalance: 'CREDIT', level: 2, parentId: conta8.id },
      { code: '88', name: 'Resultado Líquido do Exercício', accountType: 'EQUITY', normalBalance: 'CREDIT', level: 2, parentId: conta8.id },
    ],
  });

  // ============================================
  // ANO FISCAL
  // ============================================
  console.log('Criando ano fiscal...');
  await prisma.fiscalYear.create({
    data: {
      name: '2024',
      startDate: new Date('2024-01-01'),
      endDate: new Date('2024-12-31'),
    },
  });

  // ============================================
  // IMPOSTOS ANGOLA
  // ============================================
  console.log('Criando impostos Angola...');
  await prisma.tax.createMany({
    data: [
      { name: 'IVA', code: 'IVA', rate: 14, description: 'Imposto sobre o Valor Acrescentado' },
      { name: 'IRC', code: 'IRC', rate: 25, description: 'Imposto sobre o Rendimento das Pessoas Coletivas' },
      { name: 'IRT', code: 'IRT', rate: 0, description: 'Imposto sobre o Rendimento do Trabalho (tabelas progressivas)' },
      { name: 'IAC', code: 'IAC', rate: 2, description: 'Imposto sobre Aplicações de Capital' },
      { name: 'SISA', code: 'SISA', rate: 2, description: 'Imposto sobre Transmissão de Bens Imóveis' },
      { name: 'IP', code: 'IP', rate: 0.5, description: 'Imposto Predial' },
    ],
  });

  // ============================================
  // API KEYS PARA B2B
  // ============================================
  console.log('Criando API Keys para parceiros B2B...');
  await prisma.apiKey.create({
    data: {
      userId: agentB2B.id,
      name: 'API Agente Parceiro',
      key: 'sk_live_' + Buffer.from(Date.now().toString()).toString('base64url'),
      permissions: JSON.stringify(['tours:read', 'accommodations:read', 'bookings:create', 'bookings:read']),
    },
  });

  console.log('✅ Seed concluído com sucesso!');
  console.log('');
  console.log('📋 Utilizadores criados:');
  console.log('   Super Admin: admin@sincetur.com / admin123');
  console.log('   Admin: gerente@sincetur.com / admin123');
  console.log('   Agente B2B: agente@parceiro.com / admin123');
  console.log('   Cliente B2C: cliente@gmail.com / admin123');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
