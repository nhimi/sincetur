// Angola Provinces
export const ANGOLA_PROVINCES = [
  { value: "luanda", label: "Luanda" },
  { value: "benguela", label: "Benguela" },
  { value: "huila", label: "Huíla" },
  { value: "namibe", label: "Namibe" },
  { value: "huambo", label: "Huambo" },
  { value: "cabinda", label: "Cabinda" },
  { value: "zaire", label: "Zaire" },
  { value: "uige", label: "Uíge" },
  { value: "malanje", label: "Malanje" },
  { value: "kwanza_norte", label: "Kwanza Norte" },
  { value: "kwanza_sul", label: "Kwanza Sul" },
  { value: "beng0", label: "Beng0" },
  { value: "cunene", label: "Cunene" },
  { value: "kuando_kubango", label: "Kuando Kubango" },
  { value: "moxico", label: "Moxico" },
  { value: "luanda_norte", label: "Lunda Norte" },
  { value: "lunda_sul", label: "Lunda Sul" },
] as const;

// Tour Categories
export const TOUR_CATEGORIES = [
  { value: "cultural", label: "Cultural", icon: "Landmark" },
  { value: "aventura", label: "Aventura", icon: "Mountain" },
  { value: "praia", label: "Praia", icon: "Umbrella" },
  { value: "safari", label: "Safari", icon: "Binoculars" },
  { value: "ecoturismo", label: "Ecoturismo", icon: "Trees" },
  { value: "gastronomico", label: "Gastronómico", icon: "Utensils" },
  { value: "historico", label: "Histórico", icon: "Castle" },
  { value: "religioso", label: "Religioso", icon: "Church" },
] as const;

// Event Categories
export const EVENT_CATEGORIES = [
  { value: "festival", label: "Festival" },
  { value: "conferencia", label: "Conferência" },
  { value: "concerto", label: "Concerto" },
  { value: "exposicao", label: "Exposição" },
  { value: "desporto", label: "Desporto" },
  { value: "cultural", label: "Cultural" },
  { value: "gastronomico", label: "Gastronómico" },
] as const;

// Accommodation Types
export const ACCOMMODATION_TYPES = [
  { value: "HOTEL", label: "Hotel" },
  { value: "POUSADA", label: "Pousada" },
  { value: "APARTAMENTO", label: "Apartamento" },
  { value: "RESORT", label: "Resort" },
  { value: "HOSTEL", label: "Hostel" },
  { value: "GUESTHOUSE", label: "Guesthouse" },
] as const;

// Visa Types
export const VISA_TYPES = [
  { value: "TURISMO", label: "Turismo" },
  { value: "NEGOCIOS", label: "Negócios" },
  { value: "ESTUDANTE", label: "Estudante" },
  { value: "TRABALHO", label: "Trabalho" },
  { value: "TRANSITO", label: "Trânsito" },
  { value: "OUTRO", label: "Outro" },
] as const;

// Visa Status
export const VISA_STATUS = [
  { value: "PENDENTE", label: "Pendente" },
  { value: "EM_ANALISE", label: "Em Análise" },
  { value: "APROVADO", label: "Aprovado" },
  { value: "REJEITADO", label: "Rejeitado" },
] as const;

// Bus Types
export const BUS_TYPES = [
  { value: "normal", label: "Normal" },
  { value: "executivo", label: "Executivo" },
  { value: "leito", label: "Leito" },
] as const;

// Flight Classes
export const FLIGHT_CLASSES = [
  { value: "economica", label: "Económica" },
  { value: "executiva", label: "Executiva" },
  { value: "primeira", label: "Primeira Classe" },
] as const;

// Booking Status
export const BOOKING_STATUS = [
  { value: "pendente", label: "Pendente" },
  { value: "confirmado", label: "Confirmado" },
  { value: "cancelado", label: "Cancelado" },
] as const;

// Payment Status
export const PAYMENT_STATUS = [
  { value: "pendente", label: "Pendente" },
  { value: "pago", label: "Pago" },
  { value: "reembolsado", label: "Reembolsado" },
] as const;

// User Roles
export const USER_ROLES = [
  { value: "SUPER_ADMIN", label: "Super Admin" },
  { value: "ADMIN", label: "Administrador" },
  { value: "AGENT_B2B", label: "Agente B2B" },
  { value: "CLIENT_B2C", label: "Cliente B2C" },
] as const;

// Currency
export const CURRENCIES = [
  { value: "AOA", label: "Kwanza (Kz)" },
  { value: "USD", label: "Dólar Americano ($)" },
] as const;

// Payment Methods
export const PAYMENT_METHODS = [
  { value: "transferencia", label: "Transferência Bancária" },
  { value: "multicaixa", label: "Multicaixa" },
  { value: "dinheiro", label: "Dinheiro" },
  { value: "usd", label: "Dólares" },
] as const;

// Tax Rates for Angola
export const TAX_RATES = {
  IVA: 14, // Imposto sobre o Valor Acrescentado
  IRR: { min: 0, max: 17 }, // Imposto sobre Rendimento de Trabalho (progressive)
  IAC: 5, // Imposto sobre Aplicações de Capitais
  IP: 2, // Imposto Predial
  SISA: 2, // SISA
} as const;

// Account Types for Chart of Accounts (SNC Angola)
export const ACCOUNT_TYPES = [
  { value: "ativo", label: "Ativo" },
  { value: "passivo", label: "Passivo" },
  { value: "capital", label: "Capital" },
  { value: "receitas", label: "Receitas" },
  { value: "despesas", label: "Despesas" },
] as const;

// Invoice Types
export const INVOICE_TYPES = [
  { value: "fatura", label: "Fatura" },
  { value: "nota_credito", label: "Nota de Crédito" },
  { value: "nota_debito", label: "Nota de Débito" },
] as const;

// Invoice Status
export const INVOICE_STATUS = [
  { value: "rascunho", label: "Rascunho" },
  { value: "emitida", label: "Emitida" },
  { value: "paga", label: "Paga" },
  { value: "cancelada", label: "Cancelada" },
] as const;

// Amenities for Accommodations
export const AMENITIES = [
  { value: "wifi", label: "Wi-Fi" },
  { value: "ac", label: "Ar Condicionado" },
  { value: "piscina", label: "Piscina" },
  { value: "restaurante", label: "Restaurante" },
  { value: "bar", label: "Bar" },
  { value: "estacionamento", label: "Estacionamento" },
  { value: "ginasio", label: "Ginásio" },
  { value: "spa", label: "Spa" },
  { value: "lavandaria", label: "Lavandaria" },
  { value: "room_service", label: "Serviço de Quarto" },
  { value: "recepcao_24h", label: "Recepção 24h" },
  { value: "tv_cabo", label: "TV Cabo" },
  { value: "cofre", label: "Cofre" },
  { value: "minibar", label: "Mini-bar" },
  { value: "varanda", label: "Varanda" },
  { value: "vista_mar", label: "Vista Mar" },
] as const;

// Difficulty Levels for Tours
export const DIFFICULTY_LEVELS = [
  { value: "facil", label: "Fácil" },
  { value: "moderado", label: "Moderado" },
  { value: "dificil", label: "Difícil" },
] as const;
