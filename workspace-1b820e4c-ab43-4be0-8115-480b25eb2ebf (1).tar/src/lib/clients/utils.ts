import { prisma } from '@/lib/db';

// ============================================
// GERAÇÃO DE CÓDIGOS
// ============================================

export async function generateClientCode(type: string = 'INDIVIDUAL'): Promise<string> {
  const prefix = type === 'COMPANY' ? 'EMP' : 'CLI';
  const year = new Date().getFullYear();
  
  const lastClient = await prisma.client.findFirst({
    where: { code: { startsWith: `${prefix}-${year}` } },
    orderBy: { code: 'desc' },
  });

  let sequence = 1;
  if (lastClient) {
    const lastSequence = parseInt(lastClient.code.split('-')[2] || '0');
    sequence = lastSequence + 1;
  }

  return `${prefix}-${year}-${sequence.toString().padStart(5, '0')}`;
}

// ============================================
// FUNÇÕES PARTILHADAS - ESTATÍSTICAS
// ============================================

export async function getClientStats(clientId: string) {
  // Obter o userId do cliente
  const client = await prisma.client.findUnique({
    where: { id: clientId },
    select: { userId: true },
  });

  if (!client || !client.userId) {
    return {
      bookings: { tours: 0, accommodations: 0, visas: 0, buses: 0, flights: 0, events: 0, total: 0 },
      financial: { totalSpent: 0, totalPaid: 0, balance: 0 },
    };
  }

  const userId = client.userId;

  const [
    tourBookings,
    accommodationBookings,
    visaRequests,
    busTickets,
    flightBookings,
    eventBookings,
    transactions,
  ] = await Promise.all([
    prisma.tourBooking.count({ where: { userId } }),
    prisma.accommodationBooking.count({ where: { userId } }),
    prisma.visaRequest.count({ where: { userId } }),
    prisma.busTicket.count({ where: { userId } }),
    prisma.flightBooking.count({ where: { userId } }),
    prisma.eventBooking.count({ where: { userId } }),
    prisma.clientTransaction.findMany({
      where: { clientId },
      select: { amount: true, type: true, status: true },
    }),
  ]);

  const totalBookings =
    tourBookings + accommodationBookings + visaRequests + busTickets + flightBookings + eventBookings;

  const totalSpent = transactions
    .filter((t) => t.type === 'DEBIT' && t.status === 'COMPLETED')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalPaid = transactions
    .filter((t) => t.type === 'CREDIT' && t.status === 'COMPLETED')
    .reduce((sum, t) => sum + t.amount, 0);

  const balance = totalSpent - totalPaid;

  return {
    bookings: {
      tours: tourBookings,
      accommodations: accommodationBookings,
      visas: visaRequests,
      buses: busTickets,
      flights: flightBookings,
      events: eventBookings,
      total: totalBookings,
    },
    financial: {
      totalSpent,
      totalPaid,
      balance,
    },
  };
}

// ============================================
// FUNÇÕES PARTILHADAS - TRANSAÇÕES
// ============================================

export async function createClientTransaction(data: {
  clientId: string;
  type: 'DEBIT' | 'CREDIT' | 'REFUND' | 'ADJUSTMENT' | 'DISCOUNT';
  category: string;
  referenceId?: string;
  description: string;
  amount: number;
  currency?: string;
  paymentMethod?: string;
}) {
  const transactionCode = `TXN-${Date.now().toString(36).toUpperCase()}`;

  const transaction = await prisma.clientTransaction.create({
    data: {
      clientId: data.clientId,
      transactionCode,
      type: data.type,
      category: data.category,
      referenceId: data.referenceId,
      description: data.description,
      amount: data.amount,
      currency: data.currency || 'Kz',
      paymentMethod: data.paymentMethod,
      status: data.type === 'CREDIT' ? 'COMPLETED' : 'PENDING',
      transactionDate: new Date(),
    },
  });

  // Atualizar última compra
  if (data.type === 'DEBIT') {
    await prisma.client.update({
      where: { id: data.clientId },
      data: { lastPurchaseAt: new Date() },
    });
  }

  return transaction;
}

// ============================================
// FUNÇÕES PARTILHADAS - RESERVAS
// ============================================

export async function getClientBookings(clientId: string, type?: string) {
  // Primeiro obter o userId do cliente
  const client = await prisma.client.findUnique({
    where: { id: clientId },
    select: { userId: true },
  });

  if (!client || !client.userId) {
    return [];
  }

  const bookings: Record<string, unknown>[] = [];

  if (!type || type === 'tour') {
    const tourBookings = await prisma.tourBooking.findMany({
      where: { userId: client.userId },
      include: {
        tour: { include: { destination: true, category: true } },
      },
    });
    bookings.push(...tourBookings.map((b) => ({ ...b, bookingType: 'tour' })));
  }

  if (!type || type === 'accommodation') {
    const accBookings = await prisma.accommodationBooking.findMany({
      where: { userId: client.userId },
      include: {
        accommodation: { include: { destination: true } },
        room: true,
      },
    });
    bookings.push(...accBookings.map((b) => ({ ...b, bookingType: 'accommodation' })));
  }

  if (!type || type === 'event') {
    const eventBookings = await prisma.eventBooking.findMany({
      where: { userId: client.userId },
      include: {
        event: { include: { destination: true, category: true } },
      },
    });
    bookings.push(...eventBookings.map((b) => ({ ...b, bookingType: 'event' })));
  }

  if (!type || type === 'bus') {
    const busTickets = await prisma.busTicket.findMany({
      where: { userId: client.userId },
      include: {
        departure: {
          include: {
            route: { include: { origin: true, destination: true } },
            bus: { include: { company: true } },
          },
        },
      },
    });
    bookings.push(...busTickets.map((b) => ({ ...b, bookingType: 'bus' })));
  }

  if (!type || type === 'visa') {
    const visaRequests = await prisma.visaRequest.findMany({
      where: { userId: client.userId },
      include: {
        country: true,
        visaType: true,
      },
    });
    bookings.push(...visaRequests.map((b) => ({ ...b, bookingType: 'visa' })));
  }

  if (!type || type === 'flight') {
    const flightBookings = await prisma.flightBooking.findMany({
      where: { userId: client.userId },
    });
    bookings.push(...flightBookings.map((b) => ({ ...b, bookingType: 'flight' })));
  }

  return bookings.sort((a, b) => {
    const dateA = (a.createdAt as Date).getTime();
    const dateB = (b.createdAt as Date).getTime();
    return dateB - dateA;
  });
}

// ============================================
// FUNÇÕES PARTILHADAS - FATURAÇÃO
// ============================================

export async function generateClientInvoice(clientId: string, data: {
  items: Array<{
    description: string;
    quantity: number;
    unitPrice: number;
    discount?: number;
  }>;
  dueDate?: Date;
  notes?: string;
}) {
  const client = await prisma.client.findUnique({
    where: { id: clientId },
  });

  if (!client) {
    throw new Error('Cliente não encontrado');
  }

  // Calcular totais
  let subtotal = 0;
  const items = data.items.map((item) => {
    const total = item.quantity * item.unitPrice * (1 - (item.discount || 0) / 100);
    subtotal += total;
    return {
      ...item,
      total,
      ivaRate: 14,
    };
  });

  const ivaAmount = subtotal * 0.14; // IVA 14% Angola
  const totalAmount = subtotal + ivaAmount;

  // Gerar número de factura
  const year = new Date().getFullYear();
  const lastInvoice = await prisma.invoice.findFirst({
    where: { invoiceNumber: { startsWith: `FT-${year}` } },
    orderBy: { invoiceNumber: 'desc' },
  });

  let sequence = 1;
  if (lastInvoice) {
    const lastSequence = parseInt(lastInvoice.invoiceNumber.split('/')[1] || '0');
    sequence = lastSequence + 1;
  }

  const invoiceNumber = `FT-${year}/${sequence.toString().padStart(5, '0')}`;

  const invoice = await prisma.invoice.create({
    data: {
      invoiceNumber,
      invoiceType: 'INVOICE',
      customerId: clientId,
      customerName: client.companyName || client.fullName,
      customerNif: client.nif || undefined,
      customerAddress: client.address,
      dueDate: data.dueDate,
      subtotal,
      taxableAmount: subtotal,
      ivaAmount,
      totalAmount,
      notes: data.notes,
      status: 'DRAFT',
      items: {
        create: items.map((item) => ({
          description: item.description,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          discount: item.discount || 0,
          ivaRate: 14,
          total: item.total,
        })),
      },
    },
    include: {
      items: true,
    },
  });

  return invoice;
}

// ============================================
// FUNÇÕES PARTILHADAS - PESQUISA
// ============================================

export async function searchClients(query: string, limit: number = 10) {
  return prisma.client.findMany({
    where: {
      OR: [
        { fullName: { contains: query } },
        { email: { contains: query } },
        { phone: { contains: query } },
        { nif: { contains: query } },
        { companyName: { contains: query } },
        { code: { contains: query } },
      ],
      isActive: true,
    },
    take: limit,
    select: {
      id: true,
      code: true,
      fullName: true,
      companyName: true,
      email: true,
      phone: true,
      nif: true,
      clientType: true,
    },
  });
}

// ============================================
// FUNÇÕES PARTILHADAS - COMUNICAÇÃO
// ============================================

export async function logClientCommunication(data: {
  clientId: string;
  userId?: string;
  type: string;
  subject?: string;
  content: string;
  direction: 'inbound' | 'outbound';
  attachments?: string[];
}) {
  const communication = await prisma.clientCommunication.create({
    data: {
      clientId: data.clientId,
      userId: data.userId,
      type: data.type,
      subject: data.subject,
      content: data.content,
      direction: data.direction,
      attachments: data.attachments ? JSON.stringify(data.attachments) : null,
    },
  });

  // Atualizar último contacto
  await prisma.client.update({
    where: { id: data.clientId },
    data: { lastContactAt: new Date() },
  });

  return communication;
}
