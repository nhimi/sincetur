'use client';

import { useEffect, useState } from 'react';
import {
  Users,
  Map,
  Building2,
  Calendar,
  CreditCard,
  TrendingUp,
  Clock,
  ArrowRight,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

interface DashboardStats {
  users: number;
  tours: number;
  accommodations: number;
  events: number;
  bookings: {
    tours: number;
    accommodations: number;
    events: number;
    bus: number;
    visa: number;
    total: number;
  };
  revenue: {
    total: number;
  };
  recentBookings: {
    tours: Array<{
      id: string;
      bookingCode: string;
      totalPriceKz: number;
      status: string;
      createdAt: string;
      tour: { title: string; destination: { name: string } };
    }>;
    accommodations: Array<{
      id: string;
      bookingCode: string;
      totalPriceKz: number;
      status: string;
      createdAt: string;
      accommodation: { name: string; destination: { name: string } };
    }>;
  };
}

const statusColors: Record<string, string> = {
  PENDING: 'bg-yellow-100 text-yellow-800',
  CONFIRMED: 'bg-blue-100 text-blue-800',
  COMPLETED: 'bg-green-100 text-green-800',
  CANCELLED: 'bg-red-100 text-red-800',
};

const statusLabels: Record<string, string> = {
  PENDING: 'Pendente',
  CONFIRMED: 'Confirmado',
  COMPLETED: 'Concluído',
  CANCELLED: 'Cancelado',
};

export function AdminDashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchStats() {
      try {
        const res = await fetch('/api/admin');
        const data = await res.json();
        if (data.success) {
          setStats(data.data);
        }
      } catch (error) {
        console.error('Error fetching stats:', error);
      } finally {
        setLoading(false);
      }
    }
    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 w-48 bg-gray-200 rounded" />
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded-lg" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-500">Bem-vindo ao painel administrativo</p>
        </div>
        <Button className="bg-orange-600 hover:bg-orange-700">
          <CreditCard className="h-4 w-4 mr-2" />
          Nova Reserva
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Reservas</p>
                <p className="text-3xl font-bold">{stats?.bookings.total || 0}</p>
                <div className="flex items-center gap-1 text-green-600 text-sm mt-1">
                  <TrendingUp className="h-4 w-4" />
                  <span>+12% este mês</span>
                </div>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-orange-100">
                <CreditCard className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Receita Total</p>
                <p className="text-3xl font-bold">
                  {(stats?.revenue.total || 0).toLocaleString()} Kz
                </p>
                <div className="flex items-center gap-1 text-green-600 text-sm mt-1">
                  <TrendingUp className="h-4 w-4" />
                  <span>+8% este mês</span>
                </div>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-green-100">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Tours Activos</p>
                <p className="text-3xl font-bold">{stats?.tours || 0}</p>
                <p className="text-gray-500 text-sm mt-1">
                  {stats?.accommodations} alojamentos
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-blue-100">
                <Map className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Utilizadores</p>
                <p className="text-3xl font-bold">{stats?.users || 0}</p>
                <p className="text-gray-500 text-sm mt-1">
                  Clientes registados
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-purple-100">
                <Users className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Booking Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card className="bg-orange-50 border-orange-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Map className="h-5 w-5 text-orange-600" />
              <div>
                <p className="text-2xl font-bold">{stats?.bookings.tours}</p>
                <p className="text-sm text-gray-600">Tours</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Building2 className="h-5 w-5 text-blue-600" />
              <div>
                <p className="text-2xl font-bold">{stats?.bookings.accommodations}</p>
                <p className="text-sm text-gray-600">Alojamentos</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-green-50 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Calendar className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-2xl font-bold">{stats?.bookings.events}</p>
                <p className="text-sm text-gray-600">Eventos</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-purple-50 border-purple-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Clock className="h-5 w-5 text-purple-600" />
              <div>
                <p className="text-2xl font-bold">{stats?.bookings.bus}</p>
                <p className="text-sm text-gray-600">Autocarros</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-yellow-50 border-yellow-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Users className="h-5 w-5 text-yellow-600" />
              <div>
                <p className="text-2xl font-bold">{stats?.bookings.visa}</p>
                <p className="text-sm text-gray-600">Vistos</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Bookings */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Tour Bookings */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg">Reservas de Tours Recentes</CardTitle>
            <Button variant="ghost" size="sm">
              Ver todas <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {stats?.recentBookings.tours.map((booking) => (
                <div
                  key={booking.id}
                  className="flex items-center justify-between border-b pb-3"
                >
                  <div>
                    <p className="font-medium">{booking.tour.title}</p>
                    <p className="text-sm text-gray-500">
                      {booking.tour.destination.name} • {booking.bookingCode}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">
                      {booking.totalPriceKz.toLocaleString()} Kz
                    </p>
                    <Badge className={statusColors[booking.status]}>
                      {statusLabels[booking.status]}
                    </Badge>
                  </div>
                </div>
              ))}
              {(!stats?.recentBookings.tours.length) && (
                <p className="text-gray-500 text-center py-4">
                  Sem reservas recentes
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Recent Accommodation Bookings */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg">Reservas de Alojamentos Recentes</CardTitle>
            <Button variant="ghost" size="sm">
              Ver todas <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {stats?.recentBookings.accommodations.map((booking) => (
                <div
                  key={booking.id}
                  className="flex items-center justify-between border-b pb-3"
                >
                  <div>
                    <p className="font-medium">{booking.accommodation.name}</p>
                    <p className="text-sm text-gray-500">
                      {booking.accommodation.destination.name} • {booking.bookingCode}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">
                      {booking.totalPriceKz.toLocaleString()} Kz
                    </p>
                    <Badge className={statusColors[booking.status]}>
                      {statusLabels[booking.status]}
                    </Badge>
                  </div>
                </div>
              ))}
              {(!stats?.recentBookings.accommodations.length) && (
                <p className="text-gray-500 text-center py-4">
                  Sem reservas recentes
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
