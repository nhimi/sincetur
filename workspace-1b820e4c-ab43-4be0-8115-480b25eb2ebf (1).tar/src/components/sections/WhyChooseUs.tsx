'use client';

import {
  Shield,
  Headphones,
  CreditCard,
  Clock,
  Award,
  Globe,
} from 'lucide-react';

const features = [
  {
    icon: Shield,
    title: 'Pagamento Seguro',
    description: 'Transações protegidas com as melhores tecnologias de segurança.',
  },
  {
    icon: Headphones,
    title: 'Suporte 24/7',
    description: 'Assistência disponível a qualquer hora, todos os dias.',
  },
  {
    icon: CreditCard,
    title: 'Preços Transparentes',
    description: 'Sem custos escondidos. O preço que vê é o que paga.',
  },
  {
    icon: Clock,
    title: 'Reserva Rápida',
    description: 'Processo de reserva simples e rápido em poucos minutos.',
  },
  {
    icon: Award,
    title: 'Qualidade Garantida',
    description: 'Fornecedores verificados e experiências de qualidade.',
  },
  {
    icon: Globe,
    title: 'Cobertura Nacional',
    description: 'Presentes em todas as províncias de Angola.',
  },
];

export function WhyChooseUs() {
  return (
    <section className="py-16 bg-gradient-to-br from-orange-600 to-red-700 text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold">Porquê Escolher a Sincetur?</h2>
          <p className="text-orange-100 mt-2 max-w-2xl mx-auto">
            Somos a sua parceira de confiança para descobrir as maravilhas de Angola 
            e além-fronteiras. Localizados no Rangel, Luanda.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="flex items-start gap-4 p-6 bg-white/10 rounded-xl backdrop-blur-sm"
            >
              <div className="flex-shrink-0">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-white/20">
                  <feature.icon className="h-6 w-6" />
                </div>
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-1">{feature.title}</h3>
                <p className="text-orange-100 text-sm">{feature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
