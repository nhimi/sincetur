import Link from "next/link";
import { Plane, Mail, Phone, MapPin, Facebook, Instagram, Twitter, Youtube } from "lucide-react";

const footerLinks = {
  services: [
    { name: "Tours", href: "#tours" },
    { name: "Alojamentos", href: "#alojamentos" },
    { name: "Voos", href: "#voos" },
    { name: "Autocarros", href: "#autocarros" },
    { name: "Vistos", href: "#vistos" },
    { name: "Eventos", href: "#eventos" },
  ],
  company: [
    { name: "Sobre nós", href: "#sobre" },
    { name: "Equipa", href: "#equipa" },
    { name: "Carreiras", href: "#carreiras" },
    { name: "Blog", href: "#blog" },
    { name: "Imprensa", href: "#imprensa" },
  ],
  support: [
    { name: "Centro de Ajuda", href: "#ajuda" },
    { name: "Contactos", href: "#contactos" },
    { name: "FAQs", href: "#faqs" },
    { name: "Termos e Condições", href: "#termos" },
    { name: "Política de Privacidade", href: "#privacidade" },
  ],
  destinations: [
    { name: "Luanda", href: "#luanda" },
    { name: "Benguela", href: "#benguela" },
    { name: "Namibe", href: "#namibe" },
    { name: "Huíla", href: "#huila" },
    { name: "Cabinda", href: "#cabinda" },
  ],
};

export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand */}
          <div className="lg:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-orange-500 to-amber-600">
                <Plane className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold text-white">Angola Viagens</span>
            </Link>
            <p className="text-sm text-gray-400 mb-4">
              A sua agência de viagens de confiança em Angola. Descubra destinos incríveis e experiências únicas.
            </p>
            <div className="flex gap-3">
              <a href="#" className="flex h-9 w-9 items-center justify-center rounded-full bg-gray-800 hover:bg-orange-600 transition-colors">
                <Facebook className="h-4 w-4" />
              </a>
              <a href="#" className="flex h-9 w-9 items-center justify-center rounded-full bg-gray-800 hover:bg-orange-600 transition-colors">
                <Instagram className="h-4 w-4" />
              </a>
              <a href="#" className="flex h-9 w-9 items-center justify-center rounded-full bg-gray-800 hover:bg-orange-600 transition-colors">
                <Twitter className="h-4 w-4" />
              </a>
              <a href="#" className="flex h-9 w-9 items-center justify-center rounded-full bg-gray-800 hover:bg-orange-600 transition-colors">
                <Youtube className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-white font-semibold mb-4">Serviços</h3>
            <ul className="space-y-2">
              {footerLinks.services.map((link) => (
                <li key={link.name}>
                  <Link href={link.href} className="text-sm hover:text-orange-500 transition-colors">
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="text-white font-semibold mb-4">Empresa</h3>
            <ul className="space-y-2">
              {footerLinks.company.map((link) => (
                <li key={link.name}>
                  <Link href={link.href} className="text-sm hover:text-orange-500 transition-colors">
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="text-white font-semibold mb-4">Suporte</h3>
            <ul className="space-y-2">
              {footerLinks.support.map((link) => (
                <li key={link.name}>
                  <Link href={link.href} className="text-sm hover:text-orange-500 transition-colors">
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white font-semibold mb-4">Contactos</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <MapPin className="h-4 w-4 mt-0.5 text-orange-500" />
                <span className="text-sm">Av. 4 de Fevereiro, 123<br />Luanda, Angola</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-4 w-4 text-orange-500" />
                <span className="text-sm">+244 923 456 789</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-4 w-4 text-orange-500" />
                <span className="text-sm">info@angolaviagens.co.ao</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="mt-12 pt-8 border-t border-gray-800 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-gray-400">
            © {new Date().getFullYear()} Angola Viagens. Todos os direitos reservados.
          </p>
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-400">Moeda:</span>
            <span className="px-2 py-1 bg-gray-800 rounded text-sm">Kz (AOA)</span>
            <span className="px-2 py-1 bg-gray-800 rounded text-sm">$ (USD)</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
