'use client';

import Link from 'next/link';
import {
  Plane,
  Phone,
  Mail,
  MapPin,
  Facebook,
  Instagram,
  Twitter,
  Linkedin,
  Youtube,
  Clock,
} from 'lucide-react';

const footerLinks = {
  tours: [
    { name: 'Cultural', href: '#' },
    { name: 'Aventura', href: '#' },
    { name: 'Praia', href: '#' },
    { name: 'Safari', href: '#' },
    { name: 'Grupos', href: '#' },
  ],
  servicos: [
    { name: 'Reserva de Voos', href: '#' },
    { name: 'Alojamentos', href: '#' },
    { name: 'Autocarros', href: '#' },
    { name: 'Vistos', href: '#' },
    { name: 'Eventos', href: '#' },
  ],
  empresa: [
    { name: 'Sobre Nós', href: '#' },
    { name: 'Termos e Condições', href: '#' },
    { name: 'Política de Privacidade', href: '#' },
    { name: 'Trabalhe Connosco', href: '#' },
    { name: 'Contacto', href: '#' },
  ],
  apoio: [
    { name: 'FAQ', href: '#' },
    { name: 'Como Reservar', href: '#' },
    { name: 'Formas de Pagamento', href: '#' },
    { name: 'Cancelamentos', href: '#' },
    { name: 'Seguro Viagem', href: '#' },
  ],
};

export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      {/* Main Footer */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Company Info */}
          <div className="lg:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-orange-500 to-red-600">
                <Plane className="h-6 w-6 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-bold text-white">Sincetur</span>
                <span className="text-xs text-orange-400 font-medium -mt-1">Viagens e Turismo</span>
              </div>
            </Link>
            <p className="text-sm mb-4">
              A sua agência de viagens de confiança em Angola. Descubra destinos incríveis 
              com pacotes personalizados e atendimento de qualidade.
            </p>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-orange-500" />
                <a href="tel:+244922862963" className="hover:text-orange-400 transition-colors">
                  +244 922 862 963
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-orange-500" />
                <a href="mailto:reservas@sincetur.com" className="hover:text-orange-400 transition-colors">
                  reservas@sincetur.com
                </a>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="h-4 w-4 text-orange-500 flex-shrink-0 mt-0.5" />
                <span>
                  AVE. Hoji ya Henda, Predio 132<br />
                  Vila Alice - Rangel - Luanda
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-orange-500" />
                <span>Seg - Sex: 8h - 18h</span>
              </div>
            </div>
          </div>

          {/* Tours */}
          <div>
            <h4 className="text-white font-semibold mb-4">Tours</h4>
            <ul className="space-y-2">
              {footerLinks.tours.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-sm hover:text-orange-400 transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Serviços */}
          <div>
            <h4 className="text-white font-semibold mb-4">Serviços</h4>
            <ul className="space-y-2">
              {footerLinks.servicos.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-sm hover:text-orange-400 transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Empresa */}
          <div>
            <h4 className="text-white font-semibold mb-4">Empresa</h4>
            <ul className="space-y-2">
              {footerLinks.empresa.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-sm hover:text-orange-400 transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Apoio */}
          <div>
            <h4 className="text-white font-semibold mb-4">Apoio ao Cliente</h4>
            <ul className="space-y-2">
              {footerLinks.apoio.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-sm hover:text-orange-400 transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Footer */}
      <div className="border-t border-gray-800">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-sm">
              © {new Date().getFullYear()} Sincetur Viagens e Turismo. Todos os direitos reservados.
            </div>
            
            {/* Social Links */}
            <div className="flex items-center gap-4">
              <a 
                href="https://facebook.com/sincetur" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-orange-400 transition-colors"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a 
                href="https://instagram.com/sincetur" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-orange-400 transition-colors"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a 
                href="https://wa.me/244922862963" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-orange-400 transition-colors"
              >
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
              </a>
            </div>

            {/* Payment Methods */}
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <span>Pagamentos:</span>
              <span className="px-2 py-1 bg-gray-800 rounded">Kwanza</span>
              <span className="px-2 py-1 bg-gray-800 rounded">USD</span>
              <span className="px-2 py-1 bg-gray-800 rounded">EUR</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
