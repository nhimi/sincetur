'use client';

import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { HeroSection } from '@/components/sections/HeroSection';
import { FeaturedTours } from '@/components/sections/FeaturedTours';
import { FeaturedAccommodations } from '@/components/sections/FeaturedAccommodations';
import { DestinationsSection } from '@/components/sections/DestinationsSection';
import { EventsSection } from '@/components/sections/EventsSection';
import { WhyChooseUs } from '@/components/sections/WhyChooseUs';
import { TestimonialsSection } from '@/components/sections/TestimonialsSection';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <HeroSection />
        <FeaturedTours />
        <DestinationsSection />
        <FeaturedAccommodations />
        <EventsSection />
        <WhyChooseUs />
        <TestimonialsSection />
      </main>
      <Footer />
    </div>
  );
}
