import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Sincetur Viagens e Turismo - Agência de Viagens em Angola",
  description: "Descubra as maravilhas de Angola com a Sincetur Viagens e Turismo. Tours, alojamentos, voos, autocarros, eventos e assessoria de vistos. A sua agência de viagens de confiança em Luanda.",
  keywords: ["viagens", "Angola", "tours", "hotéis", "turismo", "Luanda", "Benguela", "Namibe", "safari", "praia", "Sincetur", "agência de viagens"],
  authors: [{ name: "Sincetur Viagens e Turismo" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "Sincetur Viagens e Turismo - Agência de Viagens em Angola",
    description: "Descubra as maravilhas de Angola. Tours, alojamentos, voos e muito mais.",
    url: "https://sincetur.com",
    siteName: "Sincetur Viagens e Turismo",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-AO" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
