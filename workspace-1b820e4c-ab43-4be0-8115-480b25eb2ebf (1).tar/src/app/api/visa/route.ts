import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { v4 as uuidv4 } from 'uuid';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const userId = searchParams.get('userId');

    const where: Record<string, unknown> = {};
    if (status) {
      where.status = status;
    }
    if (userId) {
      where.userId = userId;
    }

    const visaRequests = await prisma.visaRequest.findMany({
      where,
      include: {
        country: true,
        visaType: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ success: true, data: visaRequests });
  } catch (error) {
    console.error('Error fetching visa requests:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao carregar pedidos de visto' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const requestCode = `VISA-${Date.now().toString(36).toUpperCase()}`;

    const visaRequest = await prisma.visaRequest.create({
      data: {
        userId: body.userId,
        countryId: body.countryId,
        visaTypeId: body.visaTypeId,
        requestCode,
        applicantName: body.applicantName,
        applicantEmail: body.applicantEmail,
        applicantPhone: body.applicantPhone,
        applicantPassport: body.applicantPassport,
        passportExpiry: new Date(body.passportExpiry),
        dateOfBirth: new Date(body.dateOfBirth),
        nationality: body.nationality,
        travelPurpose: body.travelPurpose,
        departureDate: body.departureDate ? new Date(body.departureDate) : null,
        returnDate: body.returnDate ? new Date(body.returnDate) : null,
        documents: body.documents ? JSON.stringify(body.documents) : null,
        processingFeeKz: body.processingFeeKz,
        processingFeeUsd: body.processingFeeUsd,
      },
      include: {
        country: true,
        visaType: true,
      },
    });

    return NextResponse.json({ success: true, data: visaRequest, requestCode });
  } catch (error) {
    console.error('Error creating visa request:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao criar pedido de visto' },
      { status: 500 }
    );
  }
}

export async function PATCH(request: Request) {
  try {
    const body = await request.json();
    const { id, status, notes } = body;

    const visaRequest = await prisma.visaRequest.update({
      where: { id },
      data: {
        status,
        notes,
      },
    });

    return NextResponse.json({ success: true, data: visaRequest });
  } catch (error) {
    console.error('Error updating visa request:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao atualizar pedido de visto' },
      { status: 500 }
    );
  }
}
