import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const origin = searchParams.get('origin');
    const destination = searchParams.get('destination');
    const date = searchParams.get('date');

    const where: Record<string, unknown> = { isActive: true };
    
    if (origin || destination) {
      where.route = {};
      if (origin) {
        where.route.origin = { slug: origin };
      }
      if (destination) {
        where.route.destination = { slug: destination };
      }
    }

    const departures = await prisma.busDeparture.findMany({
      where,
      include: {
        route: {
          include: {
            origin: true,
            destination: true,
            company: true,
          },
        },
        bus: {
          include: { company: true },
        },
      },
    });

    // Filter by day of week if date provided
    let filteredDepartures = departures;
    if (date) {
      const dayOfWeek = new Date(date).getDay();
      filteredDepartures = departures.filter(d => {
        const days = JSON.parse(d.daysOfWeek || '[]');
        return days.includes(dayOfWeek);
      });
    }

    return NextResponse.json({ success: true, data: filteredDepartures });
  } catch (error) {
    console.error('Error fetching bus departures:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao carregar partidas de autocarro' },
      { status: 500 }
    );
  }
}
