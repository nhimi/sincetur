import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { v4 as uuidv4 } from 'uuid';

// Get all bookings (admin) or user's bookings
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    const type = searchParams.get('type');
    const status = searchParams.get('status');

    const bookings: Record<string, unknown>[] = [];

    if (type === 'tour' || !type) {
      const tourBookings = await prisma.tourBooking.findMany({
        where: userId ? { userId } : {},
        include: {
          tour: {
            include: { destination: true, category: true },
          },
        },
        orderBy: { createdAt: 'desc' },
      });
      bookings.push(...tourBookings.map(b => ({ ...b, type: 'tour' })));
    }

    if (type === 'accommodation' || !type) {
      const accBookings = await prisma.accommodationBooking.findMany({
        where: userId ? { userId } : {},
        include: {
          accommodation: {
            include: { destination: true, type: true },
          },
          room: true,
        },
        orderBy: { createdAt: 'desc' },
      });
      bookings.push(...accBookings.map(b => ({ ...b, type: 'accommodation' })));
    }

    if (type === 'event' || !type) {
      const eventBookings = await prisma.eventBooking.findMany({
        where: userId ? { userId } : {},
        include: {
          event: {
            include: { destination: true, category: true },
          },
        },
        orderBy: { createdAt: 'desc' },
      });
      bookings.push(...eventBookings.map(b => ({ ...b, type: 'event' })));
    }

    if (type === 'bus' || !type) {
      const busTickets = await prisma.busTicket.findMany({
        where: userId ? { userId } : {},
        include: {
          departure: {
            include: {
              route: {
                include: { origin: true, destination: true },
              },
              bus: { include: { company: true } },
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      });
      bookings.push(...busTickets.map(b => ({ ...b, type: 'bus' })));
    }

    // Filter by status if provided
    const filteredBookings = status 
      ? bookings.filter(b => b.status === status)
      : bookings;

    return NextResponse.json({ success: true, data: filteredBookings });
  } catch (error) {
    console.error('Error fetching bookings:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao carregar reservas' },
      { status: 500 }
    );
  }
}

// Create a new booking
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const bookingCode = `VA-${Date.now().toString(36).toUpperCase()}`;

    let booking;

    switch (body.type) {
      case 'tour':
        booking = await prisma.tourBooking.create({
          data: {
            tourId: body.tourId,
            userId: body.userId,
            bookingCode,
            departureDate: new Date(body.departureDate),
            numberOfPeople: body.numberOfPeople,
            notes: body.notes,
            pricePerPerson: body.pricePerPerson,
            totalPriceKz: body.totalPriceKz,
            totalPriceUsd: body.totalPriceUsd,
            customerName: body.customerName,
            customerEmail: body.customerEmail,
            customerPhone: body.customerPhone,
          },
        });
        break;

      case 'accommodation':
        booking = await prisma.accommodationBooking.create({
          data: {
            accommodationId: body.accommodationId,
            roomId: body.roomId,
            userId: body.userId,
            bookingCode,
            checkIn: new Date(body.checkIn),
            checkOut: new Date(body.checkOut),
            nights: body.nights,
            adults: body.adults,
            children: body.children || 0,
            pricePerNight: body.pricePerNight,
            totalPriceKz: body.totalPriceKz,
            totalPriceUsd: body.totalPriceUsd,
            customerName: body.customerName,
            customerEmail: body.customerEmail,
            customerPhone: body.customerPhone,
            specialRequests: body.specialRequests,
          },
        });
        break;

      case 'event':
        booking = await prisma.eventBooking.create({
          data: {
            eventId: body.eventId,
            userId: body.userId,
            bookingCode,
            numberOfTickets: body.numberOfTickets,
            attendeeName: body.attendeeName,
            attendeeEmail: body.attendeeEmail,
            attendeePhone: body.attendeePhone,
            pricePerTicket: body.pricePerTicket,
            totalPriceKz: body.totalPriceKz,
            totalPriceUsd: body.totalPriceUsd,
          },
        });
        break;

      case 'bus':
        booking = await prisma.busTicket.create({
          data: {
            departureId: body.departureId,
            userId: body.userId,
            ticketCode: bookingCode,
            travelDate: new Date(body.travelDate),
            seatNumber: body.seatNumber,
            passengerName: body.passengerName,
            passengerId: body.passengerId,
            priceKz: body.priceKz,
            priceUsd: body.priceUsd,
          },
        });
        break;

      default:
        return NextResponse.json(
          { success: false, error: 'Tipo de reserva inválido' },
          { status: 400 }
        );
    }

    return NextResponse.json({ success: true, data: booking, bookingCode });
  } catch (error) {
    console.error('Error creating booking:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao criar reserva' },
      { status: 500 }
    );
  }
}
