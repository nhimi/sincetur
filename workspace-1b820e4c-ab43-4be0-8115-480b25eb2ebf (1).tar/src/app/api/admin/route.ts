import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

// Dashboard statistics
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const section = searchParams.get('section');

    // Dashboard stats
    const [
      totalUsers,
      totalTours,
      totalAccommodations,
      totalEvents,
      totalTourBookings,
      totalAccommodationBookings,
      totalEventBookings,
      totalBusTickets,
      totalVisaRequests,
      recentTourBookings,
      recentAccommodationBookings,
      revenueByMonth,
    ] = await Promise.all([
      prisma.user.count(),
      prisma.tour.count({ where: { isActive: true } }),
      prisma.accommodation.count({ where: { isActive: true } }),
      prisma.event.count({ where: { isActive: true } }),
      prisma.tourBooking.count(),
      prisma.accommodationBooking.count(),
      prisma.eventBooking.count(),
      prisma.busTicket.count(),
      prisma.visaRequest.count(),
      prisma.tourBooking.findMany({
        take: 5,
        orderBy: { createdAt: 'desc' },
        include: { tour: { include: { destination: true } } },
      }),
      prisma.accommodationBooking.findMany({
        take: 5,
        orderBy: { createdAt: 'desc' },
        include: { accommodation: { include: { destination: true } } },
      }),
      prisma.tourBooking.aggregate({
        _sum: { totalPriceKz: true },
      }),
    ]);

    const stats = {
      users: totalUsers,
      tours: totalTours,
      accommodations: totalAccommodations,
      events: totalEvents,
      bookings: {
        tours: totalTourBookings,
        accommodations: totalAccommodationBookings,
        events: totalEventBookings,
        bus: totalBusTickets,
        visa: totalVisaRequests,
        total: totalTourBookings + totalAccommodationBookings + totalEventBookings + totalBusTickets,
      },
      revenue: {
        total: revenueByMonth._sum.totalPriceKz || 0,
      },
      recentBookings: {
        tours: recentTourBookings,
        accommodations: recentAccommodationBookings,
      },
    };

    return NextResponse.json({ success: true, data: stats });
  } catch (error) {
    console.error('Error fetching admin data:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao carregar dados administrativos' },
      { status: 500 }
    );
  }
}
