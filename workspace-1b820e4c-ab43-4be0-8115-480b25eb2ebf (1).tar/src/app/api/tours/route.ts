import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const destination = searchParams.get('destination');
    const category = searchParams.get('category');
    const featured = searchParams.get('featured');
    const limit = searchParams.get('limit');

    const where: Record<string, unknown> = { isActive: true };
    
    if (destination) {
      where.destination = { slug: destination };
    }
    if (category) {
      where.category = { slug: category };
    }
    if (featured === 'true') {
      where.isFeatured = true;
    }

    const tours = await prisma.tour.findMany({
      where,
      include: {
        category: true,
        destination: true,
      },
      orderBy: { createdAt: 'desc' },
      take: limit ? parseInt(limit) : undefined,
    });

    return NextResponse.json({ success: true, data: tours });
  } catch (error) {
    console.error('Error fetching tours:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao carregar tours' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    
    const tour = await prisma.tour.create({
      data: {
        title: body.title,
        slug: body.slug || body.title.toLowerCase().replace(/\s+/g, '-'),
        description: body.description,
        shortDescription: body.shortDescription,
        categoryId: body.categoryId,
        destinationId: body.destinationId,
        duration: body.duration,
        difficulty: body.difficulty || 'MODERATE',
        maxGroupSize: body.maxGroupSize,
        minAge: body.minAge || 0,
        priceKz: body.priceKz,
        priceUsd: body.priceUsd,
        discountPercent: body.discountPercent,
        featuredImage: body.featuredImage,
        gallery: body.gallery ? JSON.stringify(body.gallery) : null,
        included: body.included ? JSON.stringify(body.included) : null,
        notIncluded: body.notIncluded ? JSON.stringify(body.notIncluded) : null,
        itinerary: body.itinerary ? JSON.stringify(body.itinerary) : null,
        departureDates: body.departureDates ? JSON.stringify(body.departureDates) : null,
        availableSeats: body.availableSeats,
        isActive: body.isActive ?? true,
        isFeatured: body.isFeatured ?? false,
      },
    });

    return NextResponse.json({ success: true, data: tour });
  } catch (error) {
    console.error('Error creating tour:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao criar tour' },
      { status: 500 }
    );
  }
}
