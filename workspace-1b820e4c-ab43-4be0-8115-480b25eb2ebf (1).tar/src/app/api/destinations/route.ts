import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function GET() {
  try {
    const destinations = await prisma.destination.findMany({
      where: { isActive: true },
      include: {
        _count: {
          select: {
            tours: true,
            accommodations: true,
            events: true,
          },
        },
      },
      orderBy: { name: 'asc' },
    });

    return NextResponse.json({ success: true, data: destinations });
  } catch (error) {
    console.error('Error fetching destinations:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao carregar destinos' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    
    const destination = await prisma.destination.create({
      data: {
        name: body.name,
        slug: body.slug || body.name.toLowerCase().replace(/\s+/g, '-'),
        province: body.province,
        country: body.country || 'Angola',
        description: body.description,
        image: body.image,
        latitude: body.latitude,
        longitude: body.longitude,
        isActive: body.isActive ?? true,
      },
    });

    return NextResponse.json({ success: true, data: destination });
  } catch (error) {
    console.error('Error creating destination:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao criar destino' },
      { status: 500 }
    );
  }
}
