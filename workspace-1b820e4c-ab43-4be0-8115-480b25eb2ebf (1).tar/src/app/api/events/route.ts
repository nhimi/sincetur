import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const upcoming = searchParams.get('upcoming');
    const limit = searchParams.get('limit');

    const where: Record<string, unknown> = { isActive: true };
    
    if (upcoming === 'true') {
      where.startDate = { gte: new Date() };
    }

    const events = await prisma.event.findMany({
      where,
      include: {
        category: true,
        destination: true,
      },
      orderBy: { startDate: 'asc' },
      take: limit ? parseInt(limit) : undefined,
    });

    return NextResponse.json({ success: true, data: events });
  } catch (error) {
    console.error('Error fetching events:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao carregar eventos' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    
    const event = await prisma.event.create({
      data: {
        title: body.title,
        slug: body.slug || body.title.toLowerCase().replace(/\s+/g, '-'),
        description: body.description,
        shortDescription: body.shortDescription,
        categoryId: body.categoryId,
        destinationId: body.destinationId,
        venue: body.venue,
        address: body.address,
        startDate: new Date(body.startDate),
        endDate: new Date(body.endDate),
        capacity: body.capacity,
        availableSeats: body.availableSeats || body.capacity,
        priceKz: body.priceKz,
        priceUsd: body.priceUsd,
        featuredImage: body.featuredImage,
        gallery: body.gallery ? JSON.stringify(body.gallery) : null,
        isActive: body.isActive ?? true,
        isFeatured: body.isFeatured ?? false,
      },
    });

    return NextResponse.json({ success: true, data: event });
  } catch (error) {
    console.error('Error creating event:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao criar evento' },
      { status: 500 }
    );
  }
}
