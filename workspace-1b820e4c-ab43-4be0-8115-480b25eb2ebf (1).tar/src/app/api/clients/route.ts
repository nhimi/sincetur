import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { generateClientCode } from '@/lib/clients/utils';

// Listar clientes
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const search = searchParams.get('search');
    const status = searchParams.get('status');
    const type = searchParams.get('type');
    const category = searchParams.get('category');

    const where: Record<string, unknown> = {};

    if (search) {
      where.OR = [
        { fullName: { contains: search } },
        { email: { contains: search } },
        { nif: { contains: search } },
        { companyName: { contains: search } },
        { phone: { contains: search } },
      ];
    }

    if (status) {
      where.status = status;
    }

    if (type) {
      where.clientType = type;
    }

    if (category) {
      where.category = category;
    }

    const [clients, total] = await Promise.all([
      prisma.client.findMany({
        where,
        include: {
          contacts: { where: { isPrimary: true }, take: 1 },
          _count: {
            select: {
              bookings_tour: true,
              bookings_accommodation: true,
              visa_requests: true,
              bus_tickets: true,
              event_bookings: true,
              transactions: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.client.count({ where }),
    ]);

    // Calcular estatísticas por cliente
    const clientsWithStats = clients.map((client) => ({
      ...client,
      totalBookings:
        client._count.bookings_tour +
        client._count.bookings_accommodation +
        client._count.visa_requests +
        client._count.bus_tickets +
        client._count.event_bookings,
      primaryContact: client.contacts[0] || null,
    }));

    return NextResponse.json({
      success: true,
      data: clientsWithStats,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching clients:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao carregar clientes' },
      { status: 500 }
    );
  }
}

// Criar novo cliente
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const code = await generateClientCode(body.clientType);

    const client = await prisma.client.create({
      data: {
        code,
        ref: body.ref,
        clientType: body.clientType || 'INDIVIDUAL',
        firstName: body.firstName,
        lastName: body.lastName,
        fullName: body.fullName || `${body.firstName || ''} ${body.lastName || ''}`.trim(),
        dateOfBirth: body.dateOfBirth ? new Date(body.dateOfBirth) : null,
        gender: body.gender,
        maritalStatus: body.maritalStatus,
        companyName: body.companyName,
        tradeName: body.tradeName,
        nif: body.nif,
        nipc: body.nipc,
        economicActivity: body.economicActivity,
        companySize: body.companySize,
        foundedYear: body.foundedYear,
        employeeCount: body.employeeCount,
        email: body.email,
        phone: body.phone,
        mobilePhone: body.mobilePhone,
        fax: body.fax,
        website: body.website,
        address: body.address,
        addressNumber: body.addressNumber,
        addressComplement: body.addressComplement,
        neighborhood: body.neighborhood,
        city: body.city,
        province: body.province,
        country: body.country || 'Angola',
        postalCode: body.postalCode,
        notes: body.notes,
        tags: body.tags ? JSON.stringify(body.tags) : null,
        source: body.source,
        category: body.category,
        rating: body.rating || 0,
        loyaltyPoints: body.loyaltyPoints || 0,
        creditLimit: body.creditLimit || 0,
        paymentTerms: body.paymentTerms || 0,
        paymentMethod: body.paymentMethod,
        status: body.status || 'ACTIVE',
        acceptsMarketing: body.acceptsMarketing || false,
        userId: body.userId,
      },
      include: {
        contacts: true,
        addresses: true,
      },
    });

    // Log da atividade
    await prisma.activityLog.create({
      data: {
        action: 'CREATE',
        entity: 'CLIENT',
        entityId: client.id,
        details: `Cliente criado: ${client.fullName} (${client.code})`,
      },
    });

    return NextResponse.json({ success: true, data: client });
  } catch (error) {
    console.error('Error creating client:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao criar cliente' },
      { status: 500 }
    );
  }
}
