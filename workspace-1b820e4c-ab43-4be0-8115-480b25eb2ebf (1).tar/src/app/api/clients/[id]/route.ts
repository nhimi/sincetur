import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getClientStats, getClientBookings } from '@/lib/clients/utils';

// Obter cliente por ID
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);
    const includeStats = searchParams.get('stats') === 'true';
    const includeBookings = searchParams.get('bookings') === 'true';

    const client = await prisma.client.findUnique({
      where: { id },
      include: {
        contacts: true,
        addresses: true,
        documents: true,
        notes_history: {
          orderBy: { createdAt: 'desc' },
          take: 10,
        },
        user: {
          select: {
            id: true,
            email: true,
            name: true,
            role: true,
            avatar: true,
          },
        },
      },
    });

    if (!client) {
      return NextResponse.json(
        { success: false, error: 'Cliente não encontrado' },
        { status: 404 }
      );
    }

    const response: Record<string, unknown> = { success: true, data: client };

    // Incluir estatísticas
    if (includeStats) {
      response.stats = await getClientStats(id);
    }

    // Incluir reservas recentes
    if (includeBookings) {
      response.bookings = await getClientBookings(id);
    }

    return NextResponse.json(response);
  } catch (error) {
    console.error('Error fetching client:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao carregar cliente' },
      { status: 500 }
    );
  }
}

// Atualizar cliente
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    const client = await prisma.client.update({
      where: { id },
      data: {
        firstName: body.firstName,
        lastName: body.lastName,
        fullName: body.fullName,
        dateOfBirth: body.dateOfBirth ? new Date(body.dateOfBirth) : null,
        gender: body.gender,
        maritalStatus: body.maritalStatus,
        companyName: body.companyName,
        tradeName: body.tradeName,
        nif: body.nif,
        nipc: body.nipc,
        economicActivity: body.economicActivity,
        companySize: body.companySize,
        foundedYear: body.foundedYear,
        employeeCount: body.employeeCount,
        email: body.email,
        phone: body.phone,
        mobilePhone: body.mobilePhone,
        fax: body.fax,
        website: body.website,
        address: body.address,
        addressNumber: body.addressNumber,
        addressComplement: body.addressComplement,
        neighborhood: body.neighborhood,
        city: body.city,
        province: body.province,
        country: body.country,
        postalCode: body.postalCode,
        notes: body.notes,
        tags: body.tags ? JSON.stringify(body.tags) : undefined,
        source: body.source,
        category: body.category,
        rating: body.rating,
        loyaltyPoints: body.loyaltyPoints,
        creditLimit: body.creditLimit,
        paymentTerms: body.paymentTerms,
        paymentMethod: body.paymentMethod,
        status: body.status,
        isActive: body.isActive,
        isVerified: body.isVerified,
        acceptsMarketing: body.acceptsMarketing,
      },
    });

    // Log da atividade
    await prisma.activityLog.create({
      data: {
        action: 'UPDATE',
        entity: 'CLIENT',
        entityId: client.id,
        details: `Cliente atualizado: ${client.fullName} (${client.code})`,
      },
    });

    return NextResponse.json({ success: true, data: client });
  } catch (error) {
    console.error('Error updating client:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao atualizar cliente' },
      { status: 500 }
    );
  }
}

// Eliminar cliente (soft delete)
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    // Verificar se o cliente tem transacções
    const transactions = await prisma.clientTransaction.count({
      where: { clientId: id },
    });

    if (transactions > 0) {
      // Soft delete - apenas marcar como inativo
      const client = await prisma.client.update({
        where: { id },
        data: { isActive: false, status: 'INACTIVE' },
      });

      return NextResponse.json({
        success: true,
        message: 'Cliente desativado (possui histórico)',
        data: client,
      });
    }

    // Hard delete se não houver transacções
    await prisma.client.delete({
      where: { id },
    });

    return NextResponse.json({
      success: true,
      message: 'Cliente eliminado com sucesso',
    });
  } catch (error) {
    console.error('Error deleting client:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao eliminar cliente' },
      { status: 500 }
    );
  }
}
