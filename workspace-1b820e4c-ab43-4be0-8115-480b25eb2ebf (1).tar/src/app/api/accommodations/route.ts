import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const destination = searchParams.get('destination');
    const type = searchParams.get('type');
    const featured = searchParams.get('featured');
    const limit = searchParams.get('limit');

    const where: Record<string, unknown> = { isActive: true };
    
    if (destination) {
      where.destination = { slug: destination };
    }
    if (type) {
      where.type = { slug: type };
    }
    if (featured === 'true') {
      where.isFeatured = true;
    }

    const accommodations = await prisma.accommodation.findMany({
      where,
      include: {
        type: true,
        destination: true,
        amenities: {
          include: {
            amenity: true,
          },
        },
        rooms: true,
      },
      orderBy: { createdAt: 'desc' },
      take: limit ? parseInt(limit) : undefined,
    });

    return NextResponse.json({ success: true, data: accommodations });
  } catch (error) {
    console.error('Error fetching accommodations:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao carregar alojamentos' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    
    const accommodation = await prisma.accommodation.create({
      data: {
        name: body.name,
        slug: body.slug || body.name.toLowerCase().replace(/\s+/g, '-'),
        description: body.description,
        shortDescription: body.shortDescription,
        typeId: body.typeId,
        destinationId: body.destinationId,
        address: body.address,
        latitude: body.latitude,
        longitude: body.longitude,
        stars: body.stars || 3,
        totalRooms: body.totalRooms,
        checkInTime: body.checkInTime || '14:00',
        checkOutTime: body.checkOutTime || '12:00',
        priceFromKz: body.priceFromKz,
        priceFromUsd: body.priceFromUsd,
        featuredImage: body.featuredImage,
        gallery: body.gallery ? JSON.stringify(body.gallery) : null,
        cancellationPolicy: body.cancellationPolicy,
        petsAllowed: body.petsAllowed ?? false,
        smokingAllowed: body.smokingAllowed ?? false,
        isActive: body.isActive ?? true,
        isFeatured: body.isFeatured ?? false,
      },
    });

    return NextResponse.json({ success: true, data: accommodation });
  } catch (error) {
    console.error('Error creating accommodation:', error);
    return NextResponse.json(
      { success: false, error: 'Erro ao criar alojamento' },
      { status: 500 }
    );
  }
}
